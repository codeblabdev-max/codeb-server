/**
 * Prisma 클라이언트 - db.server.ts의 별칭
 */

export { db as prisma, db } from "./db.server";
