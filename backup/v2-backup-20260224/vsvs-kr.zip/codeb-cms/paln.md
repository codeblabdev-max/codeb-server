# Leo Company Full-Stack AI Automation System
## 전략 기획서: 왜 이 구조인가

**Version:** 1.0  
**작성일:** 2025년 1월  
**작성자:** CEO/CTO Leo  
**문서 목적:** 시스템 설계의 사고 과정과 전략적 결정 근거 기록

---

# Part 1. 문제 인식 — 왜 이 시스템이 필요한가

## 1.1 현재 개발 환경의 근본적 한계

스타트업과 중소기업의 개발팀은 공통적인 구조적 문제에 직면해 있다. 6명의 개발자가 10개의 프로젝트를 동시에 운영하면서, 각 프로젝트마다 다른 포트 번호를 기억하고, 다른 데이터베이스 설정을 관리하며, 서로 다른 배포 프로세스를 따라야 한다.

이 혼란은 단순한 불편함이 아니다. 실질적인 비용이고, 성장의 병목이며, 기술 부채의 근원이다.

### 문제 1: 컨텍스트 스위칭 비용

UC Irvine의 Gloria Mark 교수 연구에 따르면, 개발자가 하나의 작업에서 다른 작업으로 전환할 때 평균 23분 15초의 집중력 회복 시간이 필요하다. 이건 단순히 "다시 집중하는 데 걸리는 시간"이 아니다. 작업 맥락을 머릿속에 다시 로드하고, 어디까지 했는지 파악하고, 다음에 뭘 해야 하는지 재인식하는 인지적 오버헤드다.

우리 팀에서 하루에 3번만 프로젝트를 전환해도 개발자당 1시간 이상이 순수한 "전환 비용"으로 소모된다. 6명 기준으로 하루 6시간, 한 달이면 약 120시간이 허공으로 사라진다. 이건 1.5명분의 개발 리소스가 증발하는 것과 같다.

더 심각한 건 이 비용이 "보이지 않는다"는 점이다. 개발자들은 바쁘게 일하고 있고, 야근도 하고, 열심히 하는데 결과물이 기대만큼 안 나온다. 원인을 찾아보면 구조적 비효율이 곳곳에 숨어 있다.

### 문제 2: 지식의 파편화

프로젝트 A는 포트 3000번, 환경변수는 .env.local에.
프로젝트 B는 포트 3100번, 환경변수는 .env에.
프로젝트 C는 포트 8080번, Docker Compose로 띄우고.

이런 식으로 프로젝트마다 다른 규칙이 적용되면, 그 지식은 시스템에 존재하는 게 아니라 각 개발자의 머릿속에만 존재하는 "암묵지"가 된다. 신규 개발자가 합류하면 각 프로젝트를 별도로 학습해야 하고, 기존 담당자가 퇴사하면 그 지식은 그대로 유실된다.

내가 이 문제를 심각하게 인식한 건 신규 개발자 온보딩 과정에서였다. 똑똑한 개발자가 와서 첫 2주 동안 한 일이 "프로젝트별 설정 파악하기"였다. 이건 시스템의 실패다.

### 문제 3: AI 도구의 비효율적 활용

ChatGPT, Claude, GitHub Copilot 같은 AI 도구들이 개발 생산성을 혁신할 것이라는 기대가 있다. 실제로 이 도구들은 강력하다. 하지만 대부분의 팀에서 AI 도구 활용은 "개인의 역량"에 의존한다.

AI를 잘 쓰는 개발자는 생산성이 2-3배 올라가고, 잘 못 쓰는 개발자는 오히려 AI가 생성한 코드를 디버깅하느라 시간을 낭비한다. 팀 차원의 AI 활용 전략이 없으면 AI는 "개인 도구"로 남고, 조직적 역량 향상으로 이어지지 않는다.

내가 고민한 핵심 질문은 이것이다:

**"AI를 팀의 표준 워크플로우에 통합해서, 개인 역량과 무관하게 누구나 AI의 혜택을 받을 수 있는 구조를 만들 수 있을까?"**

### 문제 4: 배포와 인프라의 블랙박스화

"로컬에서는 되는데 서버에서는 안 돼요."

이 문장을 들을 때마다 나는 속으로 한숨을 쉰다. 이건 개발자 탓이 아니라 시스템 설계의 문제다. 로컬 환경과 서버 환경이 다르고, 그 차이가 명시적으로 관리되지 않으면 이런 문제는 필연적으로 발생한다.

배포 프로세스가 수동이고, 서버 설정이 문서화되지 않았으며, 인프라 변경이 구두로 전달되면... 이건 시한폭탄이다. 언젠가 터지고, 터지면 복구에 몇 시간에서 며칠이 걸린다.

### 문제 5: 확장성의 구조적 한계

지금은 6명, 10개 프로젝트다. 하지만 회사가 성장하면? 12명, 30개 프로젝트가 되면?

현재의 "사람 의존적" 구조로는 선형적 확장도 불가능하다. 프로젝트가 늘어날수록 복잡성은 기하급수적으로 증가하고, 어느 순간 전체 시스템을 파악하는 사람이 아무도 없는 상태가 된다.

나는 이런 상태를 여러 회사에서 봤다. "레거시"라고 부르는 시스템들의 대부분은 기술적으로 오래된 게 아니라 "구조적으로 관리 불가능해진" 시스템들이다.

---

## 1.2 내가 원하는 이상적인 상태

이 모든 문제를 인식한 후, 나는 "이상적인 상태"를 구체적으로 정의해 봤다.

### 이상 상태 1: 프로젝트 생성의 원클릭화

개발자가 새 프로젝트를 시작할 때, 터미널에 한 줄만 입력하면 모든 게 준비되어야 한다.

- Git 리포지토리 생성
- 데이터베이스 컨테이너 자동 생성
- 포트 번호 자동 할당 (충돌 없이)
- 환경변수 템플릿 자동 주입
- CI/CD 파이프라인 기본 설정
- 모니터링 연동

이게 되면 "프로젝트 세팅하는 데 이틀 걸렸어요" 같은 말이 사라진다.

### 이상 상태 2: 지식의 코드화

"이 프로젝트는 원래 이렇게 해야 해"라는 암묵지가 없어야 한다. 모든 규칙, 모든 설정, 모든 절차가 코드 또는 명시적 문서로 존재해야 한다.

새로운 개발자가 와도 README 하나 읽고 바로 개발을 시작할 수 있어야 한다. 아니, README도 필요 없어야 한다. 프로젝트 구조 자체가 "이렇게 하면 됩니다"를 말해야 한다.

### 이상 상태 3: AI의 조직적 통합

AI가 개인 도구가 아니라 팀의 표준 워크플로우에 녹아들어야 한다.

- 기획 단계에서 AI가 PRD 초안을 작성
- 설계 단계에서 AI가 아키텍처 검토
- 개발 단계에서 AI가 코드 생성 및 리뷰
- 테스트 단계에서 AI가 테스트 케이스 작성
- 배포 단계에서 AI가 인프라 스크립트 실행

이 모든 과정이 "Claude Code를 쓸 줄 아는 사람만" 가능한 게 아니라, 팀의 표준 프로세스로 정의되어야 한다.

### 이상 상태 4: 인프라의 투명화

서버가 블랙박스가 아니라 투명한 유리창이어야 한다.

- 현재 어떤 프로젝트가 어떤 포트에서 돌고 있는지 한눈에 파악
- 어떤 DB가 어떤 프로젝트에 연결되어 있는지 즉시 확인
- 배포 상태, 헬스 체크 결과, 리소스 사용량이 실시간으로 가시화

개발자가 "이 서버 뭐가 돌고 있어요?"라고 물어볼 필요가 없어야 한다. 대시보드 하나 보면 다 나와야 한다.

### 이상 상태 5: 확장 가능한 구조

10개 프로젝트나 100개 프로젝트나 관리 복잡성이 동일해야 한다.

이건 "사람이 더 열심히 일하면 된다"가 아니라 "시스템이 자동으로 처리한다"를 의미한다. 프로젝트가 늘어나도 포트 충돌 걱정 없이, DB 관리 걱정 없이, 배포 복잡성 걱정 없이 운영할 수 있어야 한다.

---

# Part 2. 설계 철학 — 어떤 원칙으로 접근했는가

## 2.1 Central Control 원칙: Leo-Centric 구조

### 왜 중앙 통제인가?

분산된 의사결정은 속도를 높여주지만, 일관성을 해친다. 특히 초기 단계에서 "각자 알아서"는 기술 부채의 지름길이다.

나는 의도적으로 "중앙 통제" 구조를 선택했다. 모든 프로젝트 생성, 모든 인프라 변경, 모든 프로덕션 배포는 정의된 프로세스를 거쳐야 한다. 이게 관료적으로 보일 수 있지만, 실제로는 더 빠르다.

왜냐하면:
- 규칙이 명확하면 의사결정에 시간이 안 걸린다
- 표준화된 프로세스는 반복할수록 빨라진다
- 예외 상황을 처리하는 비용이 사라진다

### 승인 포인트의 전략적 배치

모든 것을 통제하면 병목이 된다. 그래서 "승인이 필요한 지점"을 전략적으로 배치했다.

**승인 필요 (Leo가 직접 확인)**
- PRD 최종 승인: 잘못된 방향으로 가면 모든 후속 작업이 낭비
- 프로덕션 배포: 사용자에게 영향을 미치는 변경은 신중해야 함
- 인프라 구조 변경: 다른 프로젝트에 영향을 줄 수 있음

**자동 진행 (시스템이 처리)**
- 개발 서버 배포: 테스트 환경은 자유롭게
- 코드 리뷰 요청: 자동화된 체크 통과 시 PR 생성
- DB 마이그레이션 (개발): 스키마 변경은 빈번하므로 자동화

이렇게 하면 중요한 결정에만 사람이 개입하고, 나머지는 시스템이 알아서 처리한다.

---

## 2.2 Hybrid Intelligence 원칙: Brain + Muscle + Senses

### AI만으로는 안 된다

Claude Code는 강력하다. 코드를 생성하고, 분석하고, 리팩토링하고, 테스트를 작성한다. 하지만 Claude Code만으로는 완전한 자동화가 불가능하다.

왜?

- **Claude Code는 외부 시스템을 직접 제어하지 못한다.** SSH로 서버에 접속해서 명령어를 실행하거나, 데이터베이스 컨테이너를 생성하는 건 할 수 없다. MCP(Model Context Protocol)를 통해 일부 외부 연동이 가능하지만, 보안상 민감한 작업은 로컬에서 실행하는 게 맞다.

- **Claude Code는 "기억"에 한계가 있다.** 세션이 끝나면 컨텍스트가 사라진다. 지속적인 상태 관리(어떤 포트가 사용 중인지, 어떤 프로젝트가 어떤 DB를 쓰는지)는 별도의 시스템이 필요하다.

- **Claude Code는 비용이 든다.** 모든 작업을 AI에게 시키면 API 비용이 기하급수적으로 증가한다. 단순 반복 작업은 스크립트가, 지능이 필요한 작업만 AI가 담당해야 한다.

### 삼위일체 구조: Brain, Muscle, Senses

그래서 나는 세 가지 레이어를 분리했다.

**Brain (두뇌) — Claude Code**
- 역할: 기획, 설계, 코딩, 테스트 시나리오 작성, 코드 리뷰
- 특징: 지능이 필요한 작업, 창의성이 필요한 작업, 복잡한 분석
- 비유: 회사의 개발자들 (생각하고 판단하는 역할)

**Muscle (근육) — Leo CLI (자체 구축 도구)**
- 역할: 서버 제어, 배포 실행, DB 생성/관리, 포트 할당
- 특징: 로컬에서 실행, SSH 터널링, 실제 시스템 명령어 수행
- 비유: 회사의 인프라/DevOps 팀 (실제로 작업을 수행하는 역할)

**Senses (감각) — MCP 연동**
- 역할: GitHub, Slack, Sentry 등 외부 서비스와의 연결
- 특징: 표준화된 프로토콜, 양방향 통신, 이벤트 기반
- 비유: 회사의 커뮤니케이션 채널 (정보를 주고받는 역할)

이 세 가지가 유기적으로 연결되면, Claude Code의 "생각"이 Leo CLI의 "실행"으로 이어지고, 그 결과가 MCP를 통해 팀에게 "공유"된다.

---

## 2.3 Standardization 원칙: Core CMS 템플릿

### 왜 표준화가 중요한가?

모든 프로젝트가 다르면, 모든 프로젝트를 새로 배워야 한다.
모든 프로젝트가 같으면, 하나만 알면 전부를 안다.

물론 모든 프로젝트가 100% 같을 수는 없다. 하지만 80%는 같을 수 있다.

- 인증/로그인: 대부분의 프로젝트에 필요
- 어드민 대시보드: 관리자 기능은 거의 모든 프로젝트에 존재
- CRUD 패턴: 데이터 생성/조회/수정/삭제는 기본 중의 기본
- 파일 업로드: 이미지나 문서 업로드 기능
- 권한 관리: 사용자 역할에 따른 접근 제어

이런 공통 기능을 매번 새로 만드는 건 낭비다. "검증된 템플릿"을 만들어두고, 새 프로젝트는 이 템플릿에서 시작하면 된다.

### Core CMS의 구성

Core CMS는 다음을 포함한다:

**기술 스택 (고정)**
- Frontend: Next.js 14+ (App Router)
- Backend: Next.js API Routes + Prisma ORM
- Database: PostgreSQL
- Auth: NextAuth.js
- Styling: Tailwind CSS
- 상태관리: Zustand (필요시)

**기본 기능 모듈**
- 사용자 인증 (이메일/소셜 로그인)
- 역할 기반 권한 관리 (Admin, User, Guest)
- 기본 CRUD 템플릿
- 파일 업로드 (MinIO 연동)
- 기본 어드민 대시보드

**폴더 구조 (강제)**
```
project/
├── src/
│   ├── app/              # Next.js App Router
│   ├── components/       # React 컴포넌트
│   │   ├── ui/           # 기본 UI (Button, Input...)
│   │   └── features/     # 기능별 컴포넌트
│   ├── lib/              # 유틸리티, 헬퍼
│   ├── hooks/            # Custom Hooks
│   └── types/            # TypeScript 타입 정의
├── prisma/
│   └── schema.prisma     # DB 스키마
├── public/               # 정적 파일
├── tests/                # 테스트 코드
│   ├── e2e/              # Playwright E2E
│   └── unit/             # Jest 단위 테스트
└── .claude/              # Claude Code 설정
    ├── settings.json
    └── CLAUDE.md
```

이 구조를 "강제"하는 이유는, 어떤 프로젝트를 열어도 "아, 이건 여기 있겠네"를 바로 알 수 있게 하기 위해서다.

### 확장은 허용, 기본은 불변

Core CMS 위에 프로젝트별 기능을 추가하는 건 자유다. 하지만 Core의 구조를 변경하는 건 금지다.

예를 들어:
- ✅ 허용: `src/features/real-estate/` 폴더 추가
- ✅ 허용: 새로운 Prisma 모델 추가
- ❌ 금지: `src/app` 대신 `pages/` 사용
- ❌ 금지: NextAuth 대신 다른 인증 라이브러리 사용

이렇게 하면 Core는 안정적으로 유지되면서, 프로젝트별 커스터마이징이 가능하다.

---

## 2.4 Private PaaS 원칙: 자동화된 인프라 관리

### Public Cloud vs Private PaaS

AWS, GCP, Vercel 같은 퍼블릭 클라우드 서비스는 편리하다. 하지만 비용이 빠르게 증가하고, 벤더 종속성이 생기며, 세밀한 제어가 어렵다.

반면 자체 서버를 운영하면 비용은 절약되지만, 관리 부담이 크다. 서버 설정, 네트워크 구성, 보안 패치, 모니터링... 전문 DevOps 인력 없이는 감당하기 어렵다.

나는 중간 지점을 선택했다: **자체 서버 + 자동화 = Private PaaS**

핵심 아이디어는 이렇다. 서버는 우리 것이지만, 관리는 "플랫폼처럼" 자동화한다. 개발자가 "새 프로젝트 만들어줘"라고 하면, 시스템이 알아서 서버 설정, DB 생성, 포트 할당, 도메인 연결을 처리한다.

### Leo-Manager: PM2를 넘어서

PM2는 Node.js 프로세스 관리 도구다. `pm2 list`하면 돌고 있는 프로세스가 보이고, `pm2 restart`하면 재시작된다. 편하다.

하지만 PM2의 한계:
- 프로세스만 관리하지, DB나 Redis는 별도로 관리해야 함
- 포트 할당이 자동화되지 않음
- 프로젝트 메타데이터 관리 기능 없음

그래서 Leo-Manager를 설계했다. PM2의 편리함 + 프로젝트 전체 생명주기 관리.

**Registry (등록소)**
모든 프로젝트의 상태를 관리하는 Single Source of Truth. JSON 파일 하나에 모든 프로젝트의 포트, DB 연결, 상태, 담당자 정보가 담긴다.

**자동 포트 할당**
새 프로젝트 등록 시 사용 가능한 다음 포트를 자동으로 찾아서 할당한다. 포트 충돌 걱정이 사라진다.

**Caddy 연동**
Caddy는 자동 SSL 인증서 발급이 가능한 리버스 프록시다. 프로젝트가 추가될 때마다 Caddyfile을 자동으로 업데이트하고, `caddy reload`로 무중단 적용한다.

**상태 모니터링**
`leo manager list` 한 줄이면 모든 프로젝트의 상태, 포트, 헬스 체크 결과가 테이블로 출력된다.

---

# Part 3. Claude Code 퍼포먼스 극대화 전략

## 3.1 왜 Claude Code인가?

### AI 코딩 도구 비교에서 Claude Code를 선택한 이유

시장에는 여러 AI 코딩 도구가 있다: GitHub Copilot, Cursor, ChatGPT, Claude Code 등.

각각의 장단점을 분석한 결과:

**GitHub Copilot**
- 장점: IDE 통합이 뛰어남, 자동완성이 자연스러움
- 단점: 긴 맥락 이해가 약함, 아키텍처 수준의 작업에 부적합
- 결론: "줄 단위" 작업에는 좋지만, "프로젝트 단위" 작업에는 한계

**Cursor**
- 장점: AI-first IDE, 코드베이스 전체를 맥락으로 활용
- 단점: 특정 IDE에 종속됨, 팀 표준화 어려움
- 결론: 개인 생산성 도구로는 훌륭하지만 팀 워크플로우 통합이 어려움

**ChatGPT**
- 장점: 범용성이 높음, 설명 능력이 뛰어남
- 단점: 코드 실행 환경 없음, 파일 시스템 접근 제한적
- 결론: 학습/설명 용도로 좋지만 실제 개발 워크플로우에는 부적합

**Claude Code**
- 장점: 터미널 기반으로 유연함, 긴 맥락 처리 능력, 에이전트 시스템 구축 가능
- 단점: 초기 설정이 필요함, 학습 곡선 있음
- 결론: 팀 워크플로우에 통합하기 가장 적합

Claude Code를 선택한 결정적 이유는 "확장성"이다. 단순히 코드 자동완성 도구가 아니라, 여러 에이전트를 구성해서 복잡한 워크플로우를 자동화할 수 있다. 이건 다른 도구에서는 불가능하거나 매우 어렵다.

### Claude Code의 핵심 강점

**200K 토큰 컨텍스트**
Claude는 약 200,000 토큰의 컨텍스트 윈도우를 가진다. 이건 약 50만 글자, 책 한 권 분량이다. 대규모 코드베이스의 여러 파일을 동시에 이해하고 작업할 수 있다는 의미다.

**CLAUDE.md 시스템**
프로젝트 루트에 CLAUDE.md 파일을 두면, Claude Code가 해당 파일을 먼저 읽고 프로젝트 맥락을 이해한다. 이건 "프로젝트별 프롬프트 엔지니어링"을 가능하게 한다.

**서브에이전트 구조**
단일 Claude 인스턴스가 아니라, 역할별로 분리된 여러 에이전트를 구성할 수 있다. PM 에이전트, 백엔드 에이전트, 프론트엔드 에이전트가 각자의 역할을 수행하고, 오케스트레이터가 조율한다.

**Tool 연동**
MCP를 통해 외부 도구(GitHub, Slack, 데이터베이스 등)와 연동할 수 있다. Claude가 직접 PR을 생성하거나, Slack 메시지를 보내거나, DB 쿼리를 실행할 수 있다.

---

## 3.2 에이전트 설계: 왜 8개인가?

### 에이전트 분할의 원칙

에이전트를 어떻게 나눌지는 중요한 설계 결정이다. 너무 적으면 역할이 모호해지고, 너무 많으면 조율 비용이 증가한다.

나는 "책임의 명확성"과 "조율 복잡성" 사이에서 균형점을 찾았다.

**고려한 요소들:**

1. **단일 책임 원칙 (Single Responsibility)**
   - 각 에이전트는 명확한 하나의 역할만 담당해야 한다
   - "이 작업은 누가 하는 거지?"라는 질문에 즉답이 가능해야 한다

2. **커뮤니케이션 오버헤드**
   - 에이전트 간 정보 전달에는 비용이 든다
   - 토큰 사용량, 응답 시간, 컨텍스트 손실

3. **실제 개발 워크플로우와의 매핑**
   - 실제 개발팀의 역할 분담과 유사해야 직관적이다
   - PM, 백엔드 개발자, 프론트엔드 개발자, QA, DevOps...

4. **모델 비용 최적화**
   - 모든 에이전트가 Opus(가장 비싼 모델)일 필요는 없다
   - 역할에 따라 적절한 모델을 배치해야 비용 효율적이다

### 최종 에이전트 구조: 8+1 시스템

**@orchestrator (Opus)**
- 역할: 전체 워크플로우 조율, 작업 분배, 최종 검수
- 왜 Opus: 가장 복잡한 판단이 필요함. 여러 에이전트의 결과를 종합하고 품질을 평가해야 함
- 트리거: `/feature-dev`, `/review-all`

**@pm-spec (Sonnet)**
- 역할: 요구사항 분석, PRD 작성, Leo 컨펌 유도
- 왜 Sonnet: 문서 작성은 창의성보다 정확성이 중요. Sonnet이면 충분
- 트리거: `/new-project`, `/update-prd`

**@architect (Sonnet)**
- 역할: DB 스키마 설계, API 설계, 인프라 스펙 결정
- 왜 Sonnet: 설계는 중요하지만 패턴화된 경우가 많음
- 트리거: PRD 승인 후 자동, `/design`

**@backend-dev (Sonnet)**
- 역할: Next.js API 개발, Prisma 스키마, 비즈니스 로직
- 왜 Sonnet: 코드 생성은 Sonnet이 가장 비용 효율적
- 트리거: 설계 완료 후 자동, `/code-backend`

**@frontend-dev (Sonnet)**
- 역할: React 컴포넌트, UI 구현, API 연동
- 왜 Sonnet: 프론트엔드 코드 생성도 Sonnet이면 충분
- 트리거: API 명세 완료 후, `/code-frontend`

**@qa-gate (Sonnet)**
- 역할: 코드 리뷰, 린트 체크, 보안 점검
- 왜 Sonnet: 체크리스트 기반 검증은 복잡한 추론이 필요 없음
- 트리거: 개발 완료 시 자동, `/review`

**@e2e-tester (Sonnet)**
- 역할: Playwright 테스트 시나리오 작성 및 실행
- 왜 Sonnet: 테스트 코드 생성은 패턴화되어 있음
- 트리거: QA 통과 후, `/test`

**@infra-ops (Sonnet)**
- 역할: Leo-Manager 제어, 배포 스크립트 실행
- 왜 Sonnet: 스크립트 실행은 단순한 명령어 조합
- 트리거: `/deploy`

### 왜 더 세분화하지 않았는가?

처음에는 더 세분화하는 것을 고려했다:
- DB 전용 에이전트
- 인증 전용 에이전트
- 테스트 데이터 전용 에이전트

하지만 검토 결과, 이런 세분화는 오버엔지니어링이다.

**세분화하지 않은 이유:**
1. 조율 복잡성이 기하급수적으로 증가
2. 각 에이전트가 가져야 할 컨텍스트가 중복됨
3. 작은 작업을 위해 에이전트 간 핸드오프가 빈번해짐
4. 디버깅이 어려워짐 (어디서 문제가 생겼는지 추적 어려움)

대신, 역할별 에이전트 내에서 "스킬(Skills)"로 세부 기능을 분리했다. @backend-dev 에이전트가 DB 관련 스킬, API 관련 스킬, 인증 관련 스킬을 가지고 있는 식이다.

---

## 3.3 Skills 시스템: 지식의 모듈화

### Skills란 무엇인가?

Skills는 에이전트가 참조하는 "지식 베이스"다. 프롬프트에 매번 모든 정보를 넣는 대신, 필요한 정보를 모듈화해서 관리한다.

예를 들어, @backend-dev가 Prisma 관련 작업을 할 때:
- 매번: "Prisma는 이렇게 쓰고, 우리 프로젝트에서는 이런 컨벤션이고..."
- Skills 사용: "prisma-conventions 스킬 참조" → 자동으로 관련 정보 로드

### 핵심 Skills 구성

**core-cms (필수)**
- Leo Company의 표준 CMS 템플릿 구조
- 파일/폴더 네이밍 컨벤션
- 컴포넌트 작성 패턴
- API 라우트 구조

**leo-infra (필수)**
- 서버 IP 및 역할 정의
- 포트 할당 규칙 (App: 3000번대, DB: 5400번대)
- Podman 명령어 레퍼런스
- Leo-Manager CLI 사용법

**testing (필수)**
- Playwright E2E 테스트 패턴
- Jest 단위 테스트 패턴
- 테스트 데이터 시딩 전략
- Mock 작성 가이드라인

**security (선택)**
- 보안 체크리스트
- 일반적인 취약점 패턴
- NextAuth 보안 설정
- API 인증/인가 패턴

### Skills의 장점

**1. 일관성**
모든 에이전트가 같은 Skills를 참조하므로, 생성되는 코드의 스타일이 일관됨

**2. 유지보수**
컨벤션이 바뀌면 Skills만 업데이트하면 됨. 모든 에이전트에 자동 적용

**3. 온보딩**
새로운 팀원이 와도 Skills 문서를 읽으면 프로젝트 컨벤션을 파악 가능

**4. 토큰 효율성**
공통 정보를 Skills로 분리하면 각 프롬프트가 가벼워짐

---

## 3.4 CLAUDE.md 전략: 프로젝트별 맥락 주입

### CLAUDE.md의 역할

프로젝트 루트에 위치한 CLAUDE.md 파일은 Claude Code가 해당 프로젝트를 이해하기 위한 "첫 번째 진입점"이다.

Claude Code는 작업 시작 시 이 파일을 자동으로 읽고, 프로젝트의 맥락을 파악한다. 이건 매번 "이 프로젝트는 이런 프로젝트야"라고 설명하는 수고를 덜어준다.

### CLAUDE.md에 포함해야 할 내용

**프로젝트 개요**
- 프로젝트의 목적과 비즈니스 컨텍스트
- 주요 사용자와 유스케이스
- 현재 개발 단계 (MVP, Beta, Production)

**기술 스택**
- 사용 중인 프레임워크, 라이브러리 버전
- 주요 의존성과 그 선택 이유
- 제약사항 (예: IE 지원 필요, 특정 라이브러리 사용 금지)

**코드 컨벤션**
- 네이밍 규칙
- 파일 구조 규칙
- 코멘트 스타일
- Git 커밋 메시지 형식

**자주 하는 작업**
- 자주 사용하는 명령어
- 테스트 실행 방법
- 로컬 개발 환경 설정

**주의사항**
- 알려진 이슈
- 건드리면 안 되는 레거시 코드
- 성능 민감 영역

### CLAUDE.md 템플릿

```markdown
# Project: [프로젝트명]

## Overview
[프로젝트 설명 2-3문장]

## Tech Stack
- Frontend: Next.js 14, React 18, TypeScript
- Backend: Next.js API Routes, Prisma
- Database: PostgreSQL 15
- Auth: NextAuth.js v5

## Key Commands
- `npm run dev`: 개발 서버 시작
- `npm run test:e2e`: E2E 테스트 실행
- `npm run db:migrate`: DB 마이그레이션

## Code Conventions
- 컴포넌트: PascalCase (예: UserProfile.tsx)
- 유틸리티: camelCase (예: formatDate.ts)
- API 라우트: kebab-case (예: user-profile/route.ts)

## Dos and Don'ts
✅ DO: Prisma 스키마 변경 시 마이그레이션 파일 생성
❌ DON'T: node_modules 직접 수정
❌ DON'T: .env 파일을 Git에 커밋
```

---

## 3.5 비용 최적화 전략

### 모델별 비용 구조 이해

Anthropic의 Claude 모델은 세 가지 티어가 있다:
- **Opus**: 가장 강력하지만 가장 비쌈 (입력 $15/M 토큰, 출력 $75/M 토큰)
- **Sonnet**: 균형잡힌 성능과 가격 (입력 $3/M 토큰, 출력 $15/M 토큰)
- **Haiku**: 빠르고 저렴 (입력 $0.25/M 토큰, 출력 $1.25/M 토큰)

Opus는 Sonnet보다 5배 비싸다. 모든 작업에 Opus를 쓰면 비용이 감당 불가능해진다.

### 역할별 모델 배치 전략

**Opus를 쓰는 경우 (5%)**
- @orchestrator: 전체 조율, 복잡한 판단
- 아키텍처 리뷰: 중요한 설계 결정
- 모호한 요구사항 해석: 창의적 판단 필요

**Sonnet을 쓰는 경우 (90%)**
- 코드 생성: 대부분의 코드 작성
- 문서 작성: PRD, 기술 문서
- 테스트 작성: 테스트 케이스 생성
- 코드 리뷰: 체크리스트 기반 검증

**Haiku를 쓰는 경우 (5%)**
- 단순 포맷팅: JSON 변환, 텍스트 정리
- 반복 작업: 템플릿 기반 생성
- 빠른 확인: Yes/No 판단

### 토큰 사용량 최적화

**불필요한 컨텍스트 제거**
- 전체 코드베이스를 매번 넘기지 않는다
- 관련 파일만 선택적으로 포함
- 히스토리는 요약해서 전달

**Skills 활용**
- 반복되는 정보는 Skills로 분리
- 필요할 때만 로드

**점진적 상세화**
- 처음부터 완벽한 결과를 요구하지 않음
- 개요 → 상세 → 구현 순서로 단계적 진행

### 예상 월간 비용

6명 개발팀 기준, 월 예상 비용:
- Opus (5%): 약 $50
- Sonnet (90%): 약 $200
- Haiku (5%): 약 $10
- **합계: 약 $260/월**

이건 개발자 1명 인건비의 1/10도 안 된다. AI 도구 비용은 인건비 대비 극히 미미하며, 생산성 향상으로 충분히 상쇄된다.

---

# Part 4. 인프라 프레임워크 설계

## 4.1 4-Layer 아키텍처

### 왜 레이어를 나눴는가?

복잡한 시스템을 다루는 가장 좋은 방법은 "관심사의 분리(Separation of Concerns)"다. 각 레이어가 자신의 역할에만 집중하면, 전체 시스템의 복잡성이 줄어든다.

나는 시스템을 4개 레이어로 나눴다:

### Layer 1: App Layer (애플리케이션 레이어)

**역할**: 실제 사용자가 사용하는 애플리케이션
**구성 요소**: Next.js 프로젝트들
**특징**:
- Stateless (상태 없음): 애플리케이션 자체는 상태를 저장하지 않음
- 수평 확장 가능: 트래픽 증가 시 인스턴스 추가
- Core CMS 기반: 표준화된 구조

이 레이어의 핵심 원칙은 "무상태성"이다. 모든 상태는 DB나 Redis에 저장되고, 앱 인스턴스는 언제든 교체 가능해야 한다.

### Layer 2: Server Layer (서버 레이어)

**역할**: 인프라 리소스 관리
**구성 요소**:
- Podman 컨테이너
- PostgreSQL 데이터베이스
- Redis 캐시
- MinIO 스토리지

**특징**:
- 역할별 서버 분리 (App, DB, Cache, Storage)
- 볼륨으로 데이터 영속성 보장
- 내부 네트워크로 보안 강화

서버를 역할별로 분리한 이유:
1. 장애 격리: DB 서버 문제가 App 서버에 영향을 주지 않음
2. 독립적 스케일링: DB만 스케일업, 캐시만 스케일업 가능
3. 보안: DB 서버는 외부 접근 차단, App 서버만 외부 노출

### Layer 3: IaC Layer (Infrastructure as Code 레이어)

**역할**: 인프라 설정의 코드화
**구성 요소**:
- 프로젝트 매니페스트 (YAML)
- 자동화 스크립트
- 환경별 설정 (dev, stage, prod)

**핵심 원칙**: 
> "프로젝트 하나 = YAML 매니페스트 하나"

모든 프로젝트의 인프라 요구사항이 하나의 YAML 파일에 정의된다. 이 파일만 보면 해당 프로젝트가 어떤 서버를 쓰고, 어떤 포트를 쓰고, 어떤 DB에 연결되는지 한눈에 파악된다.

### Layer 4: Agent/DevOps Layer (에이전트/데브옵스 레이어)

**역할**: 자동화와 조율
**구성 요소**:
- Claude 서브에이전트들
- GitHub Actions
- 배포 파이프라인

**특징**:
- 인간의 개입 최소화
- 반복 작업 자동화
- 품질 게이트 강제

이 레이어가 나머지 세 레이어를 "운영"한다. 에이전트가 코드를 생성하고, IaC가 인프라를 정의하고, 서버 레이어에 배포되어 앱 레이어가 실행된다.

---

## 4.2 프로젝트 매니페스트 설계

### 매니페스트의 목적

프로젝트 매니페스트는 해당 프로젝트의 "인프라 계약서"다. 이 문서에 정의된 대로 인프라가 구성되어야 하고, 여기에 없는 건 없는 거다.

### 매니페스트 구조

매니페스트는 다음 섹션들로 구성된다:

**project 섹션**
프로젝트의 기본 정보: ID, 타입, 담당자, 팀

**environment 섹션**
환경별 설정: 도메인, 기본 환경

**servers 섹션**
사용할 서버들의 IP 또는 역할

**resources 섹션**
리소스 할당: 포트, CPU, 메모리, Redis DB index, 스토리지 버킷

**features 섹션**
활성화할 기능: CMS 코어, 인증, 게시판, 실시간 기능

**monitoring 섹션** (신규 추가)
모니터링 설정: 알림 채널, 헬스체크 엔드포인트, 대시보드 템플릿

**backup 섹션** (신규 추가)
백업 정책: 스케줄, 보존 기간, 저장 위치

### 매니페스트가 트리거하는 것들

매니페스트가 생성/수정되면 다음이 자동으로 발생한다:

1. **DB 컨테이너 생성**: resources.db 설정에 따라
2. **Redis namespace 예약**: resources.redis.db_index 할당
3. **MinIO 버킷 생성**: resources.storage.bucket 이름으로
4. **Caddy 설정 업데이트**: environment.domains에 따라
5. **.env 파일 생성**: 위 정보들을 조합해서
6. **모니터링 등록**: monitoring 섹션에 따라
7. **백업 스케줄 등록**: backup 섹션에 따라

개발자는 매니페스트만 작성하면 된다. 나머지는 시스템이 알아서 한다.

---

## 4.3 서버 구성 상세

### 물리 서버 구성

**Test Server (Mac Mini M4) - 192.168.1.100**
- 역할: AI 연산 가속, E2E 테스트, Staging 배포, Leo-Manager 메인
- 선택 이유: M4 칩의 성능이 뛰어나고, 전력 소비가 적음. 클라우드 비용 절감
- RAM: 최소 16GB 권장 (여러 테스트 병렬 실행)

**APP Server - 192.168.1.10**
- 역할: Next.js 컨테이너 실행
- 특징: Stateless, 쉽게 교체 가능
- 앞단: Caddy 리버스 프록시

**DB Server - 192.168.1.11**
- 역할: PostgreSQL 데이터베이스
- 특징: Podman 볼륨으로 데이터 영속성
- 백업: 매일 새벽 3시 자동 백업

**Socket Server - 192.168.1.12**
- 역할: WebSocket 기반 실시간 서비스
- 필요 시에만 활성화

**Storage Server - 192.168.1.13**
- 역할: MinIO (S3 호환 오브젝트 스토리지)
- 용도: 파일 업로드, 백업 저장

**Cache Server - 192.168.1.14**
- 역할: Redis Cluster
- 용도: 세션, 캐시, 실시간 데이터

### 네트워크 구성

**외부 노출**: APP Server만 외부에서 접근 가능 (Caddy를 통해)
**내부 통신**: leo-private-net (Podman 네트워크)
**보안**:
- SSH 키 기반 인증 (패스워드 비활성화)
- 방화벽: 필요한 포트만 오픈
- DB, Redis는 내부망에서만 접근

---

## 4.4 포트 관리 전략

### 포트 충돌 문제

여러 프로젝트가 같은 서버에서 돌아가면 포트 충돌이 발생한다. "어? 이 포트 누가 쓰고 있어?" 이런 상황이 매번 벌어진다.

### 해결책: 체계적 포트 할당

**App 포트 범위: 3000-3999**
- 각 프로젝트에 순차적으로 할당
- 3000: 프로젝트 A
- 3001: 프로젝트 B
- 3002: 프로젝트 C...

**DB 포트 범위: 5400-5499**
- PostgreSQL 기본 포트(5432) 대신 별도 범위 사용
- 5400: 프로젝트 A DB
- 5401: 프로젝트 B DB...

**Redis DB Index: 0-15**
- Redis는 기본적으로 16개 DB 제공 (0-15)
- 각 프로젝트에 다른 DB index 할당
- 필요시 별도 Redis 인스턴스 추가

### Leo-Manager의 역할

Leo-Manager가 registry.json에서 현재 사용 중인 포트를 추적하고, 새 프로젝트 생성 시 다음 가용 포트를 자동 할당한다.

```
leo manager register new-project
→ "App 포트 3005, DB 포트 5405 할당됨"
```

개발자는 포트 번호를 신경 쓸 필요가 없다.

---

## 4.5 클라우드 확장 전략: LB + 오토스케일링

### 왜 오토스케일링인가?

고정 서버 구성의 딜레마:
- 서버를 적게 두면: 트래픽 폭증 시 서비스 다운
- 서버를 많이 두면: 평소에 비용 낭비

이 딜레마를 해결하는 게 오토스케일링이다. "필요할 때만 서버를 늘리고, 안 필요하면 줄인다."

### 아키텍처: 한국 리전 + LB + 오토스케일링

```
                    ┌─────────────────────────────────────────┐
                    │          Vultr 한국 리전 (서울)           │
                    │                                         │
   사용자 요청      │    ┌─────────────────────┐              │
  ──────────────────┼───▶│   Load Balancer     │              │
                    │    │   (트래픽 자동 분배)  │              │
                    │    └──────────┬──────────┘              │
                    │               │                         │
                    │    ┌──────────┼──────────┐              │
                    │    ▼          ▼          ▼              │
                    │ ┌─────┐  ┌─────┐  ┌─────┐              │
                    │ │ App │  │ App │  │ App │  ← 자동 증감  │
                    │ │ #1  │  │ #2  │  │ #3  │              │
                    │ └─────┘  └─────┘  └─────┘              │
                    │                                         │
                    │         ┌──────────────┐                │
                    │         │ Auto Scaler  │                │
                    │         │ (CPU 모니터링)│                │
                    │         └──────────────┘                │
                    └─────────────────────────────────────────┘
```

**작동 원리:**
1. **Load Balancer**: 모든 트래픽의 진입점. 요청을 여러 서버에 자동 분배
2. **Auto Scaler**: 각 서버의 CPU/메모리를 실시간 모니터링
3. **자동 증설**: CPU 70% 초과 시 새 서버 자동 생성
4. **자동 축소**: 트래픽 감소 시 불필요한 서버 자동 제거
5. **LB 재분배**: 서버 추가/제거 시 자동으로 트래픽 재분배

### 트래픽별 서버 자동 조절 시나리오

```
트래픽 (QPS)     서버 수      상태
─────────────────────────────────────────
   2,000          2대       🟢 평상시 (새벽/심야)
   5,000          3대       🟢 일반 업무 시간
  10,000          5대       🟡 피크 타임 (점심/저녁)
  20,000          8대       🟠 이벤트/프로모션
  50,000         15대       🔴 대규모 트래픽 (바이럴)
 100,000         30대       🔴 역대급 트래픽
─────────────────────────────────────────
        ↑                      ↑
   자동 감지              자동 증설/축소
```

**시각화: 하루 트래픽 패턴과 서버 수 변화**

```
서버 수
   │
 8 │                    ┌───┐
   │                    │   │     ← 저녁 피크
 6 │          ┌───┐     │   │
   │          │   │     │   │     ← 점심 피크  
 4 │      ┌───┤   ├───┐ │   ├───┐
   │      │   │   │   │ │   │   │
 2 │──────┤   │   │   ├─┤   │   ├──────
   │      │   │   │   │ │   │   │     ← 새벽 최소
   └──────┴───┴───┴───┴─┴───┴───┴──────▶ 시간
   0시   6시  12시  15시 18시 21시  24시
```

핵심: 트래픽이 줄면 서버도 자동으로 줄어서 **비용 자동 절감**

### 오토스케일링 구현 방식

**방식 1: Vultr API + Cron (직접 구현)**

```bash
#!/bin/bash
# /opt/scripts/auto-scale.sh
# 매분 실행: * * * * * /opt/scripts/auto-scale.sh

# 현재 CPU 사용률 확인
CPU_AVG=$(curl -s http://server1:9100/metrics | grep cpu_usage | awk '{print $2}')

# 70% 초과 시 서버 추가
if [ $(echo "$CPU_AVG > 70" | bc) -eq 1 ]; then
    echo "CPU $CPU_AVG% - 서버 증설 시작"
    
    # Vultr API로 새 인스턴스 생성
    curl -X POST "https://api.vultr.com/v2/instances" \
        -H "Authorization: Bearer $VULTR_API_KEY" \
        -H "Content-Type: application/json" \
        -d '{
            "region": "icn",
            "plan": "vc2-4c-16gb",
            "label": "app-server-auto",
            "os_id": 387,
            "script_id": "bootstrap-app"
        }'
    
    # LB에 새 서버 등록
    # ... LB 업데이트 로직
fi

# 30% 미만 시 서버 축소 (최소 2대 유지)
if [ $(echo "$CPU_AVG < 30" | bc) -eq 1 ]; then
    CURRENT_COUNT=$(curl -s $VULTR_API/instances | jq '.instances | length')
    if [ $CURRENT_COUNT -gt 2 ]; then
        echo "CPU $CPU_AVG% - 서버 축소"
        # 가장 오래된 auto 서버 제거
    fi
fi
```

**방식 2: Kubernetes HPA (권장 - 규모가 커지면)**

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: app-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: next-app
  minReplicas: 2
  maxReplicas: 30
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

### 왜 한국 리전(서울)인가?

**레이턴시 비교:**

| 리전 | 한국 사용자 기준 레이턴시 |
|------|-------------------------|
| 서울 (icn) | 5-10ms |
| 도쿄 (nrt) | 30-50ms |
| 싱가포르 (sgp) | 80-100ms |
| 미국 서부 (lax) | 150-200ms |

**5-10ms vs 150ms = 사용자 체감 차이 엄청남**

특히 실시간 서비스(채팅, 게임, 라이브)에서는 이 차이가 결정적이다.

### 비용 최적화 효과

**고정 서버 방식 (기존):**
- 피크 대비 서버 10대 상시 운영
- 월 비용: $800 (24시간 × 30일 × 10대)

**오토스케일링 방식 (신규):**
- 평균 4대, 피크 시만 10대
- 월 비용: 약 $350 (평균 사용량 기준)
- **절감액: 월 $450 (56% 절감)**

```
비용
  │
$800│────────────────────────  ← 고정 서버 (항상 피크 대비)
    │
$500│         ╱╲      ╱╲
    │        ╱  ╲    ╱  ╲       ← 오토스케일링 (필요할 때만)
$200│───────╱────╲──╱────╲────
    │
    └──────────────────────────▶ 시간
```

### 오토스케일링 도입 로드맵

**Phase 1: 모니터링 기반 구축 (현재)**
- Prometheus로 CPU/메모리 메트릭 수집
- Grafana 대시보드로 트래픽 패턴 파악
- 수동 스케일링으로 시작

**Phase 2: 반자동 스케일링**
- 알림 기반: "CPU 70% 초과" → Slack 알림 → 수동 서버 추가
- 스크립트화: 서버 추가/제거 원클릭

**Phase 3: 완전 자동 스케일링**
- Cron + Vultr API로 자동 증설/축소
- LB 자동 업데이트
- 사람 개입 0

**Phase 4: 쿠버네티스 전환 (선택)**
- 트래픽이 더 커지면 K8s HPA로 전환
- 더 세밀한 스케일링, 더 빠른 반응

### 핵심 정리

| 구성 요소 | 역할 |
|----------|------|
| **한국 리전** | 낮은 레이턴시 (5-10ms) |
| **Load Balancer** | 트래픽 자동 분배 |
| **Auto Scaler** | CPU 모니터링 → 서버 자동 증감 |
| **Vultr API** | 프로그래매틱 서버 생성/삭제 |

**한 줄 요약:**
> "트래픽 폭증해도 자동 대응, 트래픽 줄면 자동 비용 절감"

---

## 4.6 IaC (Infrastructure as Code): Terraform으로 인프라 코드화

### IaC가 뭐고 왜 필요한가?

**기존 방식 (수동 클릭):**
1. Vultr 콘솔 로그인
2. "Create Server" 버튼 클릭
3. 리전 선택, 스펙 선택, OS 선택...
4. 방화벽 규칙 수동 설정
5. SSH 키 수동 등록
6. 다음 서버도 같은 과정 반복...

**문제점:**
- 실수하기 쉬움 (클릭 하나 빠뜨리면 설정 다름)
- 재현 불가능 (동일한 서버 다시 만들기 어려움)
- 버전 관리 불가 (누가 언제 뭘 바꿨는지 모름)
- 확장 어려움 (서버 10대 만들려면 10번 반복)

**IaC 방식:**
```hcl
# main.tf - 이 파일 하나로 인프라 전체 정의
resource "vultr_instance" "app_server" {
  count     = 3  # 서버 3대 자동 생성
  plan      = "vc2-4c-16gb"
  region    = "icn"  # 서울
  os_id     = 387    # Ubuntu 22.04
  label     = "app-server-${count.index + 1}"
  
  ssh_key_ids = [vultr_ssh_key.deploy.id]
  firewall_group_id = vultr_firewall_group.web.id
}
```

**terraform apply** 한 번이면 서버 3대가 동일한 설정으로 생성된다.

### Terraform을 선택한 이유

**경쟁자들과 비교:**

| 도구 | 장점 | 단점 |
|------|------|------|
| **Terraform** | 멀티 클라우드, 거대한 생태계 | 학습 곡선 |
| Ansible | 서버 설정에 강함 | 인프라 생성은 약함 |
| Pulumi | 일반 언어로 작성 | 생태계 작음 |
| CloudFormation | AWS 네이티브 | AWS 전용 |

**Terraform 선택 이유:**
1. **Vultr 공식 Provider 존재**: `vultr/vultr` provider가 잘 관리됨
2. **상태 관리**: terraform.tfstate로 현재 인프라 상태 추적
3. **Plan 기능**: 실제 적용 전 변경사항 미리보기
4. **멀티 클라우드**: 나중에 AWS/GCP 추가해도 같은 도구 사용

### 우리 인프라의 Terraform 구조

```
infra-terraform/
├── environments/
│   ├── dev/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── terraform.tfvars
│   ├── staging/
│   │   └── ...
│   └── prod/
│       └── ...
├── modules/
│   ├── vultr-instance/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   ├── vultr-firewall/
│   │   └── ...
│   └── vultr-lb/
│       └── ...
└── README.md
```

**핵심 원칙: 환경별 분리 + 모듈 재사용**

### 주요 리소스 정의 예시

**1. VPC 네트워크 + 방화벽**
```hcl
# modules/vultr-firewall/main.tf
resource "vultr_firewall_group" "main" {
  description = "${var.project_name}-firewall"
}

resource "vultr_firewall_rule" "ssh" {
  firewall_group_id = vultr_firewall_group.main.id
  protocol          = "tcp"
  ip_type           = "v4"
  subnet            = var.office_ip  # 사무실 IP만 SSH 허용
  subnet_size       = 32
  port              = "22"
}

resource "vultr_firewall_rule" "http" {
  firewall_group_id = vultr_firewall_group.main.id
  protocol          = "tcp"
  ip_type           = "v4"
  subnet            = "0.0.0.0"  # 전체 허용
  subnet_size       = 0
  port              = "80"
}

resource "vultr_firewall_rule" "https" {
  firewall_group_id = vultr_firewall_group.main.id
  protocol          = "tcp"
  ip_type           = "v4"
  subnet            = "0.0.0.0"
  subnet_size       = 0
  port              = "443"
}
```

**2. App 서버 인스턴스**
```hcl
# modules/vultr-instance/main.tf
resource "vultr_instance" "app" {
  count             = var.instance_count
  plan              = var.plan
  region            = "icn"  # 서울
  os_id             = 387    # Ubuntu 22.04
  label             = "${var.project_name}-app-${count.index + 1}"
  hostname          = "${var.project_name}-app-${count.index + 1}"
  
  ssh_key_ids       = var.ssh_key_ids
  firewall_group_id = var.firewall_group_id
  
  # 서버 생성 후 초기 설정 스크립트
  script_id         = vultr_startup_script.init.id
  
  tags = [var.environment, var.project_name]
}

# 초기화 스크립트
resource "vultr_startup_script" "init" {
  name   = "${var.project_name}-init"
  type   = "boot"
  script = base64encode(<<-EOF
    #!/bin/bash
    apt-get update
    apt-get install -y podman podman-compose
    
    # Quadlet 디렉토리 생성
    mkdir -p /etc/containers/systemd
    
    # 배포 사용자 생성
    useradd -m -s /bin/bash deploy
    usermod -aG sudo deploy
  EOF
  )
}
```

**3. Load Balancer**
```hcl
# modules/vultr-lb/main.tf
resource "vultr_load_balancer" "main" {
  region              = "icn"
  label               = "${var.project_name}-lb"
  balancing_algorithm = "roundrobin"
  
  forwarding_rules {
    frontend_protocol = "https"
    frontend_port     = 443
    backend_protocol  = "http"
    backend_port      = 3000
  }
  
  health_check {
    protocol            = "http"
    port                = 3000
    path                = "/api/health"
    check_interval      = 10
    response_timeout    = 5
    unhealthy_threshold = 3
    healthy_threshold   = 2
  }
  
  ssl {
    certificate = var.ssl_cert
    private_key = var.ssl_key
  }
}

# 인스턴스들을 LB에 연결
resource "vultr_load_balancer_target_group" "app" {
  load_balancer_id = vultr_load_balancer.main.id
  
  dynamic "instance" {
    for_each = var.app_instance_ids
    content {
      instance_id = instance.value
    }
  }
}
```

### Terraform 워크플로우

```
┌─────────────────────────────────────────────────────────────┐
│                    Terraform 워크플로우                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  1. terraform init     → Provider 다운로드, 초기화          │
│         ↓                                                   │
│  2. terraform plan     → 변경사항 미리보기 (Dry Run)         │
│         ↓                                                   │
│  3. terraform apply    → 실제 인프라 생성/수정              │
│         ↓                                                   │
│  4. terraform.tfstate  → 현재 상태 저장 (버전 관리 필수!)    │
│                                                             │
│  롤백: terraform destroy → 전체 인프라 삭제                  │
│  또는: Git에서 이전 버전 checkout → terraform apply          │
└─────────────────────────────────────────────────────────────┘
```

### Terraform + Git = 인프라 버전 관리

```bash
# 인프라 변경 이력
git log --oneline infra-terraform/

a1b2c3d 서버 4대 → 6대 증설
d4e5f6g 방화벽 규칙 추가: 사무실 IP
g7h8i9j LB 헬스체크 간격 조정
j0k1l2m 초기 인프라 구성
```

**"누가 언제 왜 인프라를 바꿨는지" 완벽 추적 가능**

---

## 4.7 런타임 운영: Podman + Quadlet + systemd

### 왜 쿠버네티스가 아닌가?

쿠버네티스는 강력하다. 하지만:

| 항목 | Kubernetes | Podman + Quadlet |
|------|------------|------------------|
| 학습 곡선 | 매우 가파름 (6개월+) | 완만함 (1-2주) |
| 최소 리소스 | Control Plane만 4GB+ | 거의 없음 |
| 운영 복잡도 | 높음 (etcd, API server...) | 낮음 (systemd만) |
| 적합 규모 | 100+ 컨테이너 | 10-50 컨테이너 |

**우리 규모 (6명, 10개 프로젝트)에서 K8s는 오버엔지니어링이다.**

대신 Podman + Quadlet + systemd 조합을 선택했다. 이 조합이 주는 것:
- 컨테이너 실행 (Podman)
- 선언적 설정 (Quadlet)
- 자동 재시작/감시 (systemd)
- **쿠버네티스의 핵심 가치를 훨씬 단순하게 얻음**

### Quadlet이 뭔가?

Quadlet은 컨테이너 설정을 systemd 서비스 파일로 변환해주는 도구다.

**기존 방식 (수동 관리):**
```bash
# 컨테이너 직접 실행
podman run -d --name myapp -p 3000:3000 myapp:latest

# 문제: 서버 재부팅하면? 컨테이너 죽으면?
# → 수동으로 다시 실행해야 함
```

**Quadlet 방식 (선언적 관리):**
```ini
# /etc/containers/systemd/myapp.container
[Container]
Image=ghcr.io/leocompany/myapp:latest
PublishPort=3000:3000
Environment=NODE_ENV=production
Environment=DATABASE_URL=postgresql://...

[Service]
Restart=always
RestartSec=10

[Install]
WantedBy=default.target
```

이 파일 하나 두면:
- 서버 부팅 시 자동 시작
- 컨테이너 죽으면 10초 후 자동 재시작
- `systemctl status myapp` 로 상태 확인
- `journalctl -u myapp` 로 로그 확인

### PM2 vs Quadlet+systemd 비교

PM2는 Node.js 세계에서 널리 쓰이는 프로세스 관리자다. 왜 Quadlet을 선택했는가?

| 항목 | PM2 | Quadlet + systemd |
|------|-----|-------------------|
| **적용 범위** | Node.js 전용 | 모든 컨테이너 (Node, Go, Python...) |
| **의존성** | Node.js 런타임 필요 | OS 내장 (추가 설치 없음) |
| **컨테이너 지원** | 별도 설정 필요 | 네이티브 지원 |
| **로그 관리** | pm2 logs | journalctl (시스템 통합) |
| **리소스 제한** | 제한적 | cgroups 완벽 지원 |
| **보안** | 일반 사용자 권한 | SELinux/AppArmor 통합 |
| **표준화** | Node.js 생태계 한정 | 리눅스 표준 |

**핵심 차이:**
- PM2: "Node.js 앱을 관리하는 도구"
- Quadlet+systemd: "리눅스 시스템이 컨테이너를 관리"

PM2는 좋은 도구지만, 컨테이너 중심 아키텍처에서는 Quadlet이 더 적합하다.

### 실제 Quadlet 설정 예시

**Next.js 앱 컨테이너:**
```ini
# /etc/containers/systemd/nextjs-app.container
[Unit]
Description=Next.js Application
After=network-online.target
Wants=network-online.target

[Container]
Image=ghcr.io/leocompany/nextjs-app:latest
PublishPort=3000:3000
Network=leo-private-net

# 환경변수
Environment=NODE_ENV=production
Environment=NEXTAUTH_URL=https://app.leocompany.com
EnvironmentFile=/etc/leocompany/nextjs-app.env

# 리소스 제한
PodmanArgs=--memory=2g --cpus=2

# 헬스체크
HealthCmd=curl -f http://localhost:3000/api/health || exit 1
HealthInterval=30s
HealthTimeout=10s
HealthRetries=3

[Service]
Restart=always
RestartSec=10
TimeoutStartSec=300

[Install]
WantedBy=multi-user.target
```

**PostgreSQL 데이터베이스:**
```ini
# /etc/containers/systemd/postgres.container
[Unit]
Description=PostgreSQL Database
Before=nextjs-app.service

[Container]
Image=postgres:15
PublishPort=5432:5432
Network=leo-private-net

Environment=POSTGRES_USER=leo
Environment=POSTGRES_PASSWORD_FILE=/run/secrets/db_password
Environment=POSTGRES_DB=leoapp

# 데이터 영속성
Volume=/var/lib/leocompany/postgres:/var/lib/postgresql/data:Z

# 리소스 제한
PodmanArgs=--memory=4g --cpus=2

[Service]
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
```

### 서비스 관리 명령어

```bash
# 상태 확인
systemctl status nextjs-app

# 시작/정지/재시작
systemctl start nextjs-app
systemctl stop nextjs-app
systemctl restart nextjs-app

# 로그 확인
journalctl -u nextjs-app -f          # 실시간 로그
journalctl -u nextjs-app --since today  # 오늘 로그

# 부팅 시 자동 시작 설정
systemctl enable nextjs-app

# 설정 변경 후 리로드
systemctl daemon-reload
systemctl restart nextjs-app
```

**익숙한 명령어로 컨테이너 관리 - 새로 배울 게 없음**

### 배포 자동화 템플릿

서버에 새 버전 배포 시:

```bash
#!/bin/bash
# /opt/scripts/deploy.sh

APP_NAME=$1
NEW_TAG=$2

echo "🚀 배포 시작: $APP_NAME → $NEW_TAG"

# 1. 새 이미지 Pull
podman pull ghcr.io/leocompany/$APP_NAME:$NEW_TAG

# 2. Quadlet 파일의 이미지 태그 업데이트
sed -i "s|Image=.*$APP_NAME:.*|Image=ghcr.io/leocompany/$APP_NAME:$NEW_TAG|" \
    /etc/containers/systemd/$APP_NAME.container

# 3. systemd 리로드 및 재시작
systemctl daemon-reload
systemctl restart $APP_NAME

# 4. 헬스체크 대기
echo "⏳ 헬스체크 대기 중..."
for i in {1..30}; do
    if curl -s http://localhost:3000/api/health | grep -q "ok"; then
        echo "✅ 배포 성공!"
        exit 0
    fi
    sleep 2
done

echo "❌ 헬스체크 실패 - 롤백 필요"
exit 1
```

---

## 4.8 CI/CD: GitHub Actions + AI 빌드 분석

### CI/CD 파이프라인 전체 흐름

```
┌────────────────────────────────────────────────────────────────────┐
│                         CI/CD 파이프라인                            │
├────────────────────────────────────────────────────────────────────┤
│                                                                    │
│  개발자                                                            │
│    │                                                               │
│    ▼                                                               │
│  ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    │
│  │  코드    │───▶│  빌드   │───▶│ 테스트  │───▶│ 이미지  │    │
│  │  Push    │    │ (Next.js)│    │ (Jest,   │    │ 빌드    │    │
│  └──────────┘    └──────────┘    │ Playwright)   └──────────┘    │
│                                  └──────────┘          │          │
│                                       │                ▼          │
│                                       │         ┌──────────┐      │
│                                       │         │ Registry │      │
│                                       │         │ (GHCR)   │      │
│                                       │         └──────────┘      │
│  ┌──────────┐    ┌──────────┐        │                │          │
│  │  Slack   │◀───│ 배포    │◀───────┴────────────────┘          │
│  │  알림    │    │ (서버)   │                                     │
│  └──────────┘    └──────────┘                                     │
│                       │                                            │
│                       ▼                                            │
│                 ┌──────────┐                                       │
│                 │ Quadlet  │                                       │
│                 │ +systemd │                                       │
│                 │ 자동재시작│                                       │
│                 └──────────┘                                       │
└────────────────────────────────────────────────────────────────────┘
```

### GitHub Actions 워크플로우

```yaml
# .github/workflows/deploy.yml
name: Build and Deploy

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}

jobs:
  # ========== 빌드 & 테스트 ==========
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      
      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      
      - name: Install dependencies
        run: npm ci
      
      - name: Type check
        run: npm run type-check
      
      - name: Lint
        run: npm run lint
      
      - name: Unit tests
        run: npm run test
      
      - name: Build
        run: npm run build
      
      - name: E2E tests
        run: npm run test:e2e

  # ========== 이미지 빌드 & 푸시 ==========
  docker:
    needs: build
    runs-on: ubuntu-latest
    if: github.event_name == 'push'
    
    permissions:
      contents: read
      packages: write
    
    outputs:
      image_tag: ${{ steps.meta.outputs.tags }}
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Log in to Container Registry
        uses: docker/login-action@v3
        with:
          registry: ${{ env.REGISTRY }}
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}
      
      - name: Extract metadata
        id: meta
        uses: docker/metadata-action@v5
        with:
          images: ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}
          tags: |
            type=sha,prefix=
            type=ref,event=branch
      
      - name: Build and push
        uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: ${{ steps.meta.outputs.tags }}
          cache-from: type=gha
          cache-to: type=gha,mode=max

  # ========== 배포 ==========
  deploy-dev:
    needs: docker
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/develop'
    environment: development
    
    steps:
      - name: Deploy to Dev Server
        uses: appleboy/ssh-action@v1
        with:
          host: ${{ secrets.DEV_SERVER_HOST }}
          username: deploy
          key: ${{ secrets.SSH_PRIVATE_KEY }}
          script: |
            /opt/scripts/deploy.sh nextjs-app ${{ github.sha }}
      
      - name: Notify Slack
        uses: slackapi/slack-github-action@v1
        with:
          payload: |
            {
              "text": "🚀 Dev 배포 완료: ${{ github.repository }}@${{ github.sha }}"
            }
        env:
          SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK }}

  deploy-prod:
    needs: docker
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    environment: production
    
    steps:
      - name: Deploy to Production
        uses: appleboy/ssh-action@v1
        with:
          host: ${{ secrets.PROD_SERVER_HOST }}
          username: deploy
          key: ${{ secrets.SSH_PRIVATE_KEY }}
          script: |
            /opt/scripts/deploy-bluegreen.sh nextjs-app ${{ github.sha }}
```

### AI 자동 빌드 실패 분석

빌드가 실패하면 Claude가 자동으로 원인을 분석한다.

```yaml
# .github/workflows/ai-analysis.yml
name: AI Build Failure Analysis

on:
  workflow_run:
    workflows: ["Build and Deploy"]
    types: [completed]

jobs:
  analyze-failure:
    if: ${{ github.event.workflow_run.conclusion == 'failure' }}
    runs-on: ubuntu-latest
    
    steps:
      - uses: actions/checkout@v4
      
      - name: Download logs
        uses: actions/download-artifact@v4
        with:
          name: build-logs
          run-id: ${{ github.event.workflow_run.id }}
      
      - name: Analyze with Claude
        id: analysis
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
        run: |
          # 로그 파일에서 에러 부분 추출
          ERROR_LOG=$(tail -100 build.log | grep -A 20 "error\|Error\|ERROR")
          
          # Claude API 호출
          ANALYSIS=$(curl -s https://api.anthropic.com/v1/messages \
            -H "x-api-key: $ANTHROPIC_API_KEY" \
            -H "anthropic-version: 2023-06-01" \
            -H "content-type: application/json" \
            -d "{
              \"model\": \"claude-sonnet-4-20250514\",
              \"max_tokens\": 1024,
              \"messages\": [{
                \"role\": \"user\",
                \"content\": \"다음 빌드 에러를 분석하고 해결 방법을 제시해줘:\n\n$ERROR_LOG\"
              }]
            }" | jq -r '.content[0].text')
          
          echo "analysis=$ANALYSIS" >> $GITHUB_OUTPUT
      
      - name: Create Issue with Analysis
        uses: actions/github-script@v7
        with:
          script: |
            const analysis = `${{ steps.analysis.outputs.analysis }}`;
            
            await github.rest.issues.create({
              owner: context.repo.owner,
              repo: context.repo.repo,
              title: `🔴 빌드 실패 분석: ${context.sha.substring(0, 7)}`,
              body: `## 빌드 실패 자동 분석\n\n` +
                    `**커밋:** ${context.sha}\n` +
                    `**브랜치:** ${context.ref}\n\n` +
                    `### AI 분석 결과\n\n${analysis}\n\n` +
                    `### 관련 링크\n` +
                    `- [실패한 워크플로우](${context.payload.workflow_run.html_url})`,
              labels: ['bug', 'build-failure', 'ai-analyzed']
            });
      
      - name: Notify Slack
        uses: slackapi/slack-github-action@v1
        with:
          payload: |
            {
              "text": "🔴 빌드 실패\n분석: ${{ steps.analysis.outputs.analysis }}"
            }
        env:
          SLACK_WEBHOOK_URL: ${{ secrets.SLACK_WEBHOOK }}
```

**AI 분석이 주는 가치:**
- 빌드 실패 시 에러 로그를 Claude가 자동 분석
- 원인과 해결 방법을 즉시 제시
- GitHub Issue 자동 생성
- 개발자가 로그 분석하는 시간 절약

### 테스트 환경 / 운영 환경 분리

```
┌─────────────────────────────────────────────────────────────────┐
│                        환경 분리 구조                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   develop 브랜치                    main 브랜치                 │
│        │                                │                       │
│        ▼                                ▼                       │
│   ┌─────────┐                      ┌─────────┐                 │
│   │   Dev   │                      │  Prod   │                 │
│   │ Server  │                      │ Server  │                 │
│   └─────────┘                      └─────────┘                 │
│        │                                │                       │
│   dev.app.com                      app.com                      │
│   dev-db (별도)                    prod-db                      │
│   테스트 데이터                     실제 데이터                  │
│                                                                 │
│   ✅ 자유롭게 배포                  ✅ 승인 필요                 │
│   ✅ 언제든 초기화 가능             ❌ 데이터 보존 필수          │
│   ✅ 실험 가능                      ❌ 안정성 최우선             │
└─────────────────────────────────────────────────────────────────┘
```

**환경별 설정:**

| 항목 | Development | Production |
|------|-------------|------------|
| URL | dev.app.leocompany.com | app.leocompany.com |
| DB | dev-db (테스트 데이터) | prod-db (실제 데이터) |
| 배포 트리거 | develop 브랜치 push | main 브랜치 + 승인 |
| 배포 방식 | 즉시 반영 | Blue/Green |
| 모니터링 | 기본 | 상세 + 알림 |
| 백업 | 없음 | 매일 자동 |

**GitHub Environments 설정:**
```yaml
# main → production (승인 필요)
deploy-prod:
  environment: production  # 👈 이게 승인 프로세스 트리거

# develop → development (자동)  
deploy-dev:
  environment: development  # 👈 승인 없이 자동 배포
```

### 전체 아키텍처 요약

```
┌─────────────────────────────────────────────────────────────────────────┐
│                    Leo Company 인프라 전체 구조                          │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────┐                                                        │
│  │ Terraform   │ ─── 인프라 생성 (서버, 네트워크, 방화벽, LB)            │
│  └─────────────┘                                                        │
│         │                                                               │
│         ▼                                                               │
│  ┌─────────────┐                                                        │
│  │   Vultr     │ ─── 한국 리전 (서울) 서버                               │
│  │   Servers   │     + 오토스케일링                                      │
│  └─────────────┘                                                        │
│         │                                                               │
│         ▼                                                               │
│  ┌─────────────┐                                                        │
│  │   Podman    │ ─── 컨테이너 런타임                                     │
│  │  + Quadlet  │     + 선언적 설정                                       │
│  │  + systemd  │     + 자동 재시작                                       │
│  └─────────────┘                                                        │
│         │                                                               │
│         ▼                                                               │
│  ┌─────────────┐                                                        │
│  │  GitHub     │ ─── CI/CD 파이프라인                                    │
│  │  Actions    │     + AI 빌드 분석                                      │
│  └─────────────┘                                                        │
│         │                                                               │
│         ▼                                                               │
│  ┌─────────────┐                                                        │
│  │ Prometheus  │ ─── 모니터링 + 알림                                     │
│  │ + Grafana   │                                                        │
│  └─────────────┘                                                        │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

# Part 5. 모니터링 & 백업 전략 (신규)

## 5.1 왜 모니터링이 필수인가

### 모니터링 없이 운영하면 생기는 일

"서버 느려요" → 어디가? 왜?
"에러 났어요" → 언제부터? 어디서?
"DB 연결 안 돼요" → 커넥션 풀 문제? 네트워크 문제? DB 죽었어?

모니터링 없이 이런 질문에 답하려면 서버에 직접 들어가서 로그를 뒤지고, 프로세스를 확인하고, 네트워크를 테스트해야 한다. 이게 30분~1시간이다. 그 사이에 사용자들은 서비스를 못 쓴다.

모니터링이 있으면?
대시보드 한 번 보면 된다. 5초.

### 모니터링의 세 가지 축

**Metrics (메트릭스)**
- 숫자로 표현되는 지표들
- CPU 사용률, 메모리 사용량, 요청 수, 응답 시간
- 도구: Prometheus

**Logs (로그)**
- 이벤트의 기록
- 에러 메시지, 사용자 액션, 시스템 이벤트
- 도구: Loki (또는 ELK Stack)

**Traces (트레이스)**
- 요청의 흐름 추적
- A 서비스 → B 서비스 → DB 어디서 느려졌는지
- 도구: Jaeger (선택)

우리는 Metrics + Logs에 집중한다. Traces는 마이크로서비스 규모에서 필요하고, 지금은 오버엔지니어링이다.

---

## 5.2 모니터링 스택 설계

### 선택한 스택: PLG Stack

**Prometheus**: 메트릭 수집 및 저장
- 장점: 쿠버네티스 생태계 표준, 강력한 쿼리 언어 (PromQL)
- 용도: CPU, 메모리, 요청 수, 응답 시간, 커스텀 메트릭

**Loki**: 로그 수집 및 저장
- 장점: Prometheus와 유사한 쿼리 방식, Grafana와 완벽 통합
- 용도: 애플리케이션 로그, 시스템 로그, 에러 추적

**Grafana**: 시각화 및 대시보드
- 장점: 아름다운 대시보드, 알림 기능, 다양한 데이터소스 지원
- 용도: 실시간 모니터링, 알림 관리, 리포트

### 왜 이 스택인가?

**ELK Stack (Elasticsearch + Logstash + Kibana)와 비교**
- ELK는 강력하지만 리소스를 많이 먹음
- Elasticsearch는 메모리 최소 4GB 필요
- 우리 규모에서는 오버스펙

**Datadog, New Relic과 비교**
- 훌륭한 SaaS 도구들이지만 비용이 높음
- 월 $50-200/호스트
- 우리처럼 여러 프로젝트를 운영하면 비용 폭발

PLG Stack은:
- 오픈소스, 무료
- 리소스 효율적 (Loki는 인덱싱을 최소화)
- 우리 규모에 적합

### 수집할 메트릭들

**시스템 메트릭**
- CPU 사용률 (%)
- 메모리 사용량 (GB)
- 디스크 사용량 (%)
- 네트워크 I/O

**애플리케이션 메트릭**
- 요청 수 (requests/sec)
- 응답 시간 (p50, p95, p99)
- 에러율 (%)
- 활성 사용자 수

**데이터베이스 메트릭**
- 커넥션 풀 사용량
- 쿼리 실행 시간
- 슬로우 쿼리 수
- 디스크 사용량

**비즈니스 메트릭 (선택)**
- 회원가입 수
- 주문 수
- 결제 금액

---

## 5.3 알림 전략

### 알림의 원칙

**원칙 1: 실행 가능한 알림만**
알림이 왔을 때 "그래서 뭘 해야 하는데?"라면 그건 나쁜 알림이다. 모든 알림에는 명확한 액션이 있어야 한다.

**원칙 2: 경고(Warning)와 위험(Critical) 구분**
- Warning: 인지하고 있어야 하지만 즉시 대응 불필요
- Critical: 즉시 대응 필요, 서비스 영향 있음

**원칙 3: 알림 피로(Alert Fatigue) 방지**
알림이 너무 많으면 무시하게 된다. "또 왔네" 하고 넘기다가 진짜 중요한 것도 놓친다. 알림은 정말 필요한 것만.

### 알림 채널 설계

**Slack #alerts-critical**
- 대상: Critical 레벨 알림
- 내용: 서버 다운, DB 연결 실패, 에러율 급증
- 담당: 전 팀원 멘션

**Slack #alerts-warning**
- 대상: Warning 레벨 알림
- 내용: CPU 80% 초과, 디스크 70% 초과, 응답 시간 느려짐
- 담당: DevOps 담당자

**Email (선택)**
- 대상: 일일/주간 리포트
- 내용: 서비스 상태 요약, 트렌드 분석

### 구체적인 알림 규칙

**Critical (즉시 대응)**
- 서버 응답 없음 (5분간)
- DB 커넥션 풀 100%
- 에러율 5% 초과
- 디스크 사용량 90% 초과

**Warning (인지 필요)**
- CPU 사용률 80% 초과 (10분간)
- 메모리 사용량 85% 초과
- 응답 시간 p95 > 2초
- 디스크 사용량 70% 초과

---

## 5.4 백업 전략

### 백업이 없으면 어떻게 되나

"DB 날아갔는데 백업이 없어요."

이 한 마디가 회사를 끝낼 수 있다. 실제로 백업 없이 운영하다가 데이터를 잃고 폐업한 스타트업들이 있다.

백업은 "있으면 좋은 것"이 아니라 "없으면 안 되는 것"이다.

### 3-2-1 백업 원칙

**3**: 데이터의 사본을 3개 유지
**2**: 2개의 다른 저장 매체에 저장
**1**: 1개는 물리적으로 떨어진 곳에 (offsite)

우리 적용:
1. 원본: DB 서버의 PostgreSQL
2. 로컬 백업: Storage 서버(MinIO)에 저장
3. 원격 백업: 클라우드 스토리지(S3 또는 Google Cloud Storage)에 저장

### 백업 스케줄

**데이터베이스 백업**
- 빈도: 매일 새벽 3시
- 방식: pg_dump로 full backup
- 압축: gzip
- 파일명: `{project}_{date}_{time}.sql.gz`
- 보존 기간: 7일 (로컬), 30일 (원격)

**볼륨 백업**
- 빈도: 주 1회 (일요일 새벽)
- 방식: 전체 볼륨 스냅샷
- 보존 기간: 4주

**설정 파일 백업**
- 빈도: 변경 시마다
- 방식: Git 버전 관리
- 대상: Caddyfile, docker-compose, 환경변수 템플릿

### 복구 테스트

백업만큼 중요한 게 "복구가 되는지 확인"이다.

매달 1회 복구 테스트를 진행한다:
1. 최신 백업 파일로 테스트 DB 복원
2. 애플리케이션 연결 확인
3. 데이터 정합성 검증
4. 복구 시간 측정 (RTO)
5. 결과 문서화

복구해본 적 없는 백업은 백업이 아니다.

### 롤백 전략

배포 후 문제가 발생하면 롤백해야 한다.

**애플리케이션 롤백**
- Blue/Green 배포를 사용하므로 즉시 가능
- 이전 버전 컨테이너로 트래픽 전환
- 소요 시간: 1분 이내

**DB 스키마 롤백**
- Prisma 마이그레이션 히스토리 관리
- `prisma migrate down` 명령어로 롤백
- 단, 데이터 손실 가능성 있으므로 신중하게

**데이터 롤백**
- 최신 백업에서 복원
- Point-in-time recovery는 아직 미구현 (향후 고려)

---

# Part 6. 업무 프로세스 시뮬레이션

## 6.1 Claude Code 서브에이전트의 Skills & MCP 구조

프로젝트 시뮬레이션에 앞서, 각 에이전트가 어떤 지식(Skills)을 참조하고 어떤 외부 도구(MCP)를 사용하는지 먼저 정리한다.

### Skills 시스템 개요

Skills는 에이전트가 작업 시 참조하는 "지식 베이스"다. 매번 프롬프트에 모든 정보를 넣는 대신, 필요한 지식을 모듈화해서 관리한다.

**Skills 파일 구조:**
```
~/.claude/skills/
├── core-cms/
│   └── SKILL.md          # 폴더 구조, 네이밍 규칙, 공통 패턴
├── prisma-guide/
│   └── SKILL.md          # 스키마 작성법, 마이그레이션, 쿼리 패턴
├── nextauth-patterns/
│   └── SKILL.md          # 인증/인가 구현 패턴
├── react-patterns/
│   └── SKILL.md          # 컴포넌트 설계, 훅 사용법
├── leo-infra/
│   └── SKILL.md          # 서버 목록, 포트 규칙, 배포 절차
├── playwright-patterns/
│   └── SKILL.md          # 테스트 구조, 셀렉터 규칙, 공통 헬퍼
├── security-checklist/
│   └── SKILL.md          # SQL Injection, XSS, CSRF 체크 항목
├── prd-template/
│   └── SKILL.md          # PRD 작성 포맷, 필수 항목
├── db-patterns/
│   └── SKILL.md          # DB 스키마 설계 패턴
├── api-conventions/
│   └── SKILL.md          # REST API 네이밍, 응답 포맷
├── podman-guide/
│   └── SKILL.md          # 컨테이너 실행, 볼륨, 네트워크
└── quadlet-templates/
    └── SKILL.md          # systemd 서비스 설정 템플릿
```

### 에이전트별 참조 Skills

| 에이전트 | 참조하는 Skills | 용도 |
|---------|----------------|------|
| @pm-spec | `prd-template` | PRD 작성 포맷, 필수 항목 체크리스트 |
| @architect | `db-patterns`, `api-conventions` | DB 스키마 설계 패턴, REST API 네이밍 규칙 |
| @backend-dev | `core-cms`, `prisma-guide`, `nextauth-patterns` | CMS 구조, Prisma 사용법, 인증 패턴 |
| @frontend-dev | `core-cms`, `react-patterns`, `tailwind-guide` | 컴포넌트 구조, React 훅 패턴, 스타일링 |
| @qa-gate | `code-review-checklist`, `security-checklist` | 린트 규칙, 보안 체크 항목 |
| @e2e-tester | `playwright-patterns`, `test-scenarios` | 테스트 코드 패턴, 시나리오 템플릿 |
| @infra-ops | `leo-infra`, `podman-guide`, `quadlet-templates` | 서버 IP/포트 규칙, 컨테이너 설정 |

### 주요 SKILL.md 파일 예시

**core-cms SKILL.md:**
```markdown
# Core CMS Skill

## 폴더 구조 (필수 준수)
project/
├── src/
│   ├── app/              # Next.js App Router (페이지)
│   ├── components/
│   │   ├── ui/           # 기본 UI (Button, Input, Modal)
│   │   └── features/     # 기능별 컴포넌트
│   ├── lib/              # 유틸리티, 서비스 레이어
│   ├── hooks/            # Custom React Hooks
│   └── types/            # TypeScript 타입 정의
├── prisma/
│   └── schema.prisma
└── tests/
    ├── e2e/              # Playwright
    └── unit/             # Jest

## 네이밍 규칙
- 컴포넌트: PascalCase (UserProfile.tsx)
- 유틸리티: camelCase (formatDate.ts)
- API 라우트: kebab-case (user-profile/route.ts)
- DB 테이블: snake_case (user_profiles)

## 공통 패턴
- 모든 API는 src/app/api/ 하위에 위치
- 비즈니스 로직은 src/lib/services/에 분리
- 타입은 src/types/에 중앙 관리
```

**leo-infra SKILL.md:**
```markdown
# Leo Infrastructure Skill

## 서버 구성
- Test Server (Mac Mini M4): 192.168.1.100
- App Server: 192.168.1.10
- DB Server: 192.168.1.11
- Socket Server: 192.168.1.12
- Storage Server (MinIO): 192.168.1.13
- Cache Server (Redis): 192.168.1.14

## 포트 할당 규칙
- App 포트: 3000-3999 (프로젝트별 순차 할당)
- DB 포트: 5400-5499 (프로젝트별 순차 할당)
- Redis: DB index 0-15 사용

## 레지스트리 위치
- ~/.leo-cli/registry.json
- 모든 프로젝트의 포트, 상태, 담당자 정보

## 배포 명령어
- 프로젝트 등록: leo manager register {project-name}
- 상태 확인: leo manager list
- Dev 배포: /opt/scripts/deploy.sh {app} {tag}
- Prod 배포: /opt/scripts/deploy-bluegreen.sh {app} {tag}

## Caddy 설정
- 설정 파일: /etc/caddy/Caddyfile
- 리로드: caddy reload --config /etc/caddy/Caddyfile
```

**prisma-guide SKILL.md:**
```markdown
# Prisma Guide Skill

## 스키마 작성 규칙
- 모델명: PascalCase (User, Property)
- 필드명: camelCase (createdAt, userId)
- 관계 필드: 명확한 이름 (author, properties)

## 필수 필드 (모든 모델에 포함)
model Example {
  id        String   @id @default(cuid())
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

## 마이그레이션 명령어
- 개발: npx prisma migrate dev --name {migration-name}
- 프로덕션: npx prisma migrate deploy
- 리셋: npx prisma migrate reset (주의: 데이터 삭제됨)

## 쿼리 패턴
- findMany: 목록 조회 (페이지네이션 포함)
- findUnique: 단일 조회 (id 또는 unique 필드)
- create/update/delete: CUD 작업
- 트랜잭션: prisma.$transaction([])
```

### MCP (Model Context Protocol) 연동

MCP는 Claude Code가 외부 서비스와 통신하기 위한 표준 프로토콜이다. GitHub, Slack 같은 외부 API와 연동할 때 사용한다.

**에이전트별 사용하는 MCP:**

| 에이전트 | MCP | 용도 |
|---------|-----|------|
| @pm-spec | - | (MCP 불필요, 문서 작성만) |
| @architect | - | (MCP 불필요, 설계 문서만) |
| @backend-dev | `GitHub MCP` | 코드 커밋, 브랜치 생성 |
| @frontend-dev | `GitHub MCP` | 코드 커밋, 브랜치 생성 |
| @qa-gate | `GitHub MCP` | PR 코멘트 작성, 리뷰 요청 |
| @e2e-tester | `GitHub MCP` | 테스트 결과로 PR 생성 |
| @infra-ops | `GitHub MCP`, `Slack MCP` | PR 머지, 배포 알림 |
| @orchestrator | `GitHub MCP`, `Slack MCP`, `Sentry MCP` | 전체 조율, 에러 추적 |

### MCP vs Leo CLI (로컬 도구) 구분

| 작업 | MCP 사용 | Leo CLI 사용 | 이유 |
|------|----------|-------------|------|
| GitHub PR 생성 | ✅ | - | 외부 API로 충분 |
| Slack 메시지 전송 | ✅ | - | 외부 API로 충분 |
| Sentry 에러 조회 | ✅ | - | 외부 API로 충분 |
| 서버 SSH 접속 | - | ✅ | 보안상 로컬에서만 |
| DB 컨테이너 생성 | - | ✅ | 내부 서버 직접 제어 |
| 포트 할당/관리 | - | ✅ | 로컬 레지스트리 접근 |
| Caddy 설정 변경 | - | ✅ | 서버 파일 직접 수정 |
| 배포 스크립트 실행 | - | ✅ | SSH 터널링 필요 |

**구분 원칙:**
- 외부 서비스 API가 있는 것 → MCP 사용
- 내부 서버를 직접 제어해야 하는 것 → Leo CLI (SSH) 사용

### Skills + MCP 실제 작동 예시

**예시 1: @backend-dev가 API 개발할 때**

```
@backend-dev 활성화됨

1. Skills 로드:
   [core-cms 스킬 읽음]
   → "API는 src/app/api/ 하위에 위치해야 함"
   → "비즈니스 로직은 src/lib/services/에 분리"
   
   [prisma-guide 스킬 읽음]
   → "모델명은 PascalCase, 필드는 camelCase"
   → "모든 모델에 id, createdAt, updatedAt 필수"
   
   [nextauth-patterns 스킬 읽음]
   → "인증 필요한 API는 getServerSession() 사용"
   → "권한 체크는 미들웨어에서 처리"

2. 코드 생성:
   - Skills에서 배운 패턴대로 코드 작성
   - prisma/schema.prisma에 Property 모델 추가
   - src/app/api/properties/route.ts 생성
   - src/lib/services/property.service.ts 생성

3. MCP 사용 (GitHub):
   - git checkout -b feature/property-api
   - git add .
   - git commit -m "feat: add property CRUD API"
   - git push origin feature/property-api
```

**예시 2: @infra-ops가 배포할 때**

```
@infra-ops 활성화됨

1. Skills 로드:
   [leo-infra 스킬 읽음]
   → "Dev 서버 IP: 192.168.1.10"
   → "배포 스크립트: /opt/scripts/deploy.sh"
   
   [quadlet-templates 스킬 읽음]
   → "컨테이너 설정: /etc/containers/systemd/"
   → "재시작: systemctl restart {service}"

2. Leo CLI 사용 (로컬 실행):
   - SSH로 Dev 서버 접속
   - /opt/scripts/deploy.sh real-estate-cms abc1234 실행
   - 헬스체크 확인

3. MCP 사용:
   [Slack MCP]
   → #deployments 채널에 메시지 전송
   → "✅ Dev 배포 완료: real-estate-cms@abc1234"
```

---

## 6.2 프로젝트 진행 플로우 시뮬레이션

이제 실제 프로젝트 "부동산 매물 관리 시스템"을 처음부터 끝까지 시뮬레이션한다.

### Step 1: 프로젝트 요청 접수

**누가:** Leo (CEO/CTO)
**어디서:** 터미널에서 Claude Code 실행
**무엇을:**
```bash
cd ~/projects
claude
> /new-project 부동산-매물-관리-시스템
```

**그러면 뭐가 일어나나:**
@orchestrator가 명령어를 받고 @pm-spec 에이전트를 활성화함. @pm-spec은 요구사항을 수집하기 위해 Leo에게 질문을 시작함.

---

### Step 2: 요구사항 수집 (PM-Spec 에이전트)

**활성화된 에이전트:** @pm-spec
**참조 Skills:** `prd-template`
**사용 MCP:** 없음

**@pm-spec이 하는 일:**

```
[prd-template 스킬 로드]
→ PRD에 필수로 들어가야 할 항목 확인
→ 타겟 사용자, 핵심 기능, MVP 범위, 기술 제약

[Leo에게 질문]
질문 1: "타겟 사용자가 누구인가요?"
→ Leo 답변: "부동산 중개사, 공인중개사 사무소"

질문 2: "핵심 기능이 뭔가요?"
→ Leo 답변: "매물 등록, 매물 검색, 고객 문의 관리, 계약 현황 대시보드"

질문 3: "MVP 범위는?"
→ Leo 답변: "매물 CRUD + 어드민 대시보드까지만 먼저"

질문 4: "기술 제약사항 있나요?"
→ Leo 답변: "Core CMS 기반으로, 기존 인증 시스템 그대로 사용"

[PRD 문서 생성]
→ docs/PRD-real-estate-cms.md 파일 생성
```

**산출물:** PRD 초안 (Markdown 문서)

---

### Step 3: PRD 검토 및 승인

**누가:** Leo (사람)
**무엇을:** @pm-spec이 작성한 PRD 초안을 검토

Leo가 확인하는 것:
- 비즈니스 목표가 맞게 정리됐는지
- 기능 범위가 적절한지
- 빠진 요구사항이 없는지

**Leo 액션:** 
```
> PRD 승인
```

승인되면 @orchestrator가 다음 단계 자동 진행

---

### Step 4: 인프라 자동 생성 (Infra-Ops 에이전트)

**활성화된 에이전트:** @infra-ops
**참조 Skills:** `leo-infra`, `podman-guide`
**사용 MCP:** `GitHub MCP`
**사용 로컬 도구:** `Leo CLI`

**PRD 승인되는 순간 @infra-ops가 자동 실행:**

```
[leo-infra 스킬 로드]
→ 현재 사용 중인 포트 확인
→ 다음 가용 포트: App 3005, DB 5405

[Leo CLI 실행] (로컬)
1. leo manager register real-estate-cms
   → registry.json에 프로젝트 등록
   → 포트 할당: App 3005, DB 5405

2. Podman으로 PostgreSQL 컨테이너 생성
   → podman run -d --name real-estate-db -p 5405:5432 postgres:15
   
3. .env.local 자동 생성
   → DATABASE_URL=postgresql://leo:***@192.168.1.11:5405/realestate
   → NEXTAUTH_URL=https://dev-realestate.leocompany.com

4. Caddy 설정 업데이트
   → dev-realestate.leocompany.com → localhost:3005 추가
   → caddy reload

[GitHub MCP 사용]
5. GitHub 리포지토리 생성
   → leocompany/real-estate-cms
   
6. Core CMS 템플릿 복제
   → 로그인, 어드민, 기본 CRUD 구조 포함
   
7. 초기 커밋 푸시
   → git push origin main
```

**소요 시간:** 약 2-3분 (전부 자동)

**결과:** 개발자는 git clone 받고 npm run dev 하면 바로 개발 시작 가능

---

### Step 5: 아키텍처 설계 (Architect 에이전트)

**활성화된 에이전트:** @architect
**참조 Skills:** `db-patterns`, `api-conventions`, `core-cms`
**사용 MCP:** 없음

**@architect가 하는 일:**

```
[db-patterns 스킬 로드]
→ 1:N, N:M 관계 설계 패턴
→ 인덱스 전략

[api-conventions 스킬 로드]
→ RESTful 네이밍 규칙
→ 응답 포맷 표준

[설계 문서 생성]
1. DB 스키마 설계
   - properties (매물 테이블)
     - id, title, description, price, address
     - propertyType (아파트/오피스텔/상가)
     - status (available/contracted/hidden)
   - property_images (이미지)
   - inquiries (문의)
   - contracts (계약)
   
2. API 엔드포인트 설계
   - POST   /api/properties      (매물 등록)
   - GET    /api/properties      (목록 조회)
   - GET    /api/properties/:id  (상세 조회)
   - PUT    /api/properties/:id  (수정)
   - DELETE /api/properties/:id  (삭제)
   
3. 컴포넌트 구조 제안
   - PropertyList.tsx
   - PropertyForm.tsx
   - PropertyDetail.tsx
   - PropertyCard.tsx
   - Dashboard.tsx
```

**산출물:** 
- docs/database-schema.md
- docs/api-specification.md
- docs/component-structure.md

**Leo 액션:** 설계 검토 → "승인" 또는 "수정 요청"

---

### Step 6: 백엔드 개발 (Backend-Dev 에이전트)

**활성화된 에이전트:** @backend-dev
**참조 Skills:** `core-cms`, `prisma-guide`, `nextauth-patterns`
**사용 MCP:** `GitHub MCP`

**@backend-dev가 하는 일:**

```
[core-cms 스킬 로드]
→ 폴더 구조 확인
→ API는 src/app/api/ 하위에

[prisma-guide 스킬 로드]
→ 모델 작성 규칙 확인
→ 마이그레이션 명령어 확인

[코드 생성]
1. Prisma 스키마 작성
   → prisma/schema.prisma에 Property 모델 추가
   
   model Property {
     id          String   @id @default(cuid())
     title       String
     description String?
     price       Int
     address     String
     type        PropertyType
     status      PropertyStatus @default(AVAILABLE)
     images      PropertyImage[]
     createdAt   DateTime @default(now())
     updatedAt   DateTime @updatedAt
   }

2. DB 마이그레이션 실행
   → npx prisma migrate dev --name add-property-model
   
3. API 라우트 생성
   → src/app/api/properties/route.ts (GET, POST)
   → src/app/api/properties/[id]/route.ts (GET, PUT, DELETE)
   
4. 서비스 레이어 구현
   → src/lib/services/property.service.ts
   
5. Zod 유효성 검증
   → src/lib/validations/property.ts

[GitHub MCP 사용]
6. 브랜치 생성 및 커밋
   → git checkout -b feature/property-api
   → git commit -m "feat: add property CRUD API"
   → git push origin feature/property-api
```

---

### Step 7: 프론트엔드 개발 (Frontend-Dev 에이전트)

**활성화된 에이전트:** @frontend-dev
**참조 Skills:** `core-cms`, `react-patterns`, `tailwind-guide`
**사용 MCP:** `GitHub MCP`

**@frontend-dev가 하는 일:**

```
[core-cms 스킬 로드]
→ 컴포넌트 폴더 구조 확인
→ 페이지는 src/app/, 컴포넌트는 src/components/

[react-patterns 스킬 로드]
→ 데이터 페칭: React Query 사용
→ 폼 처리: React Hook Form + Zod

[코드 생성]
1. 페이지 컴포넌트 생성
   → src/app/properties/page.tsx (목록 페이지)
   → src/app/properties/new/page.tsx (등록 페이지)
   → src/app/properties/[id]/page.tsx (상세 페이지)
   → src/app/properties/[id]/edit/page.tsx (수정 페이지)
   
2. 재사용 컴포넌트 작성
   → src/components/features/property/PropertyCard.tsx
   → src/components/features/property/PropertyForm.tsx
   → src/components/features/property/PropertyList.tsx
   → src/components/features/property/PropertyFilter.tsx
   
3. API 연동 훅
   → src/hooks/useProperties.ts (React Query)
   
4. 스타일링
   → Tailwind CSS 적용

[GitHub MCP 사용]
5. 브랜치에 커밋
   → git checkout feature/property-api
   → git commit -m "feat: add property UI components"
   → git push
```

**참고:** @backend-dev와 @frontend-dev는 병렬로 작업 가능 (API 명세가 정해진 후)

---

### Step 8: 코드 리뷰 (QA-Gate 에이전트)

**활성화된 에이전트:** @qa-gate
**참조 Skills:** `code-review-checklist`, `security-checklist`
**사용 MCP:** `GitHub MCP`

**개발 완료 후 @qa-gate가 자동 실행:**

```
[code-review-checklist 스킬 로드]
→ 린트 규칙, 타입 체크, 네이밍 규칙

[security-checklist 스킬 로드]
→ SQL Injection, XSS, CSRF, 인증 누락 체크

[자동 검사 실행]
1. 린트 체크
   → npm run lint
   → ESLint 규칙 위반 0건 ✅
   
2. 타입 체크
   → npm run type-check
   → TypeScript 에러 0건 ✅
   
3. 코드 컨벤션 검사
   → 네이밍 규칙 준수 ✅
   → 폴더 구조 정상 ✅
   
4. 보안 점검
   → SQL Injection: Prisma ORM 사용으로 안전 ✅
   → XSS: React 기본 이스케이핑 적용 ✅
   → 인증 누락: 모든 API에 세션 체크 있음 ✅
   
5. 성능 체크
   → N+1 쿼리 문제 없음 ✅
   → 불필요한 리렌더링 없음 ✅

[결과]
→ 모든 검사 통과
→ 다음 단계로 진행
```

**만약 실패하면:**
- 문제 리포트 생성
- @backend-dev 또는 @frontend-dev에게 수정 요청
- 수정 후 다시 @qa-gate 실행

---

### Step 9: E2E 테스트 (E2E-Tester 에이전트)

**활성화된 에이전트:** @e2e-tester
**참조 Skills:** `playwright-patterns`, `test-scenarios`
**사용 MCP:** `GitHub MCP`

**@e2e-tester가 하는 일:**

```
[playwright-patterns 스킬 로드]
→ 테스트 파일 구조
→ 셀렉터 규칙 (data-testid 사용)
→ 공통 헬퍼 함수

[test-scenarios 스킬 로드]
→ CRUD 기본 시나리오 템플릿
→ 권한 테스트 시나리오

[테스트 코드 생성]
→ tests/e2e/property.spec.ts

test.describe('매물 관리', () => {
  test('매물 등록 성공', async ({ page }) => {
    // 로그인
    await loginAsAdmin(page);
    // 등록 페이지 이동
    await page.goto('/properties/new');
    // 폼 입력
    await page.fill('[data-testid="title"]', '강남 오피스텔');
    await page.fill('[data-testid="price"]', '50000');
    // 제출
    await page.click('[data-testid="submit"]');
    // 성공 확인
    await expect(page).toHaveURL(/\/properties\/\w+/);
  });
  
  test('권한 없는 사용자 접근 차단', async ({ page }) => {
    await page.goto('/properties/new');
    await expect(page).toHaveURL('/login');
  });
});

[테스트 실행]
→ npx playwright test
→ 4개 테스트 모두 통과 ✅

[GitHub MCP 사용]
→ 테스트 통과 시 PR 자동 생성
→ feature/property-api → develop
→ PR 설명에 변경사항 요약 포함
```

---

### Step 10: PR 리뷰 및 머지

**누가:** Leo 또는 시니어 개발자 (사람)
**무엇을:** PR 코드 리뷰

```
[GitHub PR 내용]
Title: feat: 매물 관리 CRUD 기능 추가
Branch: feature/property-api → develop

변경사항:
- Property 모델 및 마이그레이션 추가
- 매물 CRUD API 구현
- 매물 관리 UI 컴포넌트 구현
- E2E 테스트 4건 추가

자동 검사 결과:
✅ Lint 통과
✅ Type Check 통과
✅ Unit Tests 통과
✅ E2E Tests 통과
```

**리뷰어가 확인:**
- 코드 품질
- 비즈니스 로직 정확성
- 테스트 커버리지

**승인 후:** develop 브랜치에 머지

---

### Step 11: Dev 서버 자동 배포

**트리거:** develop 브랜치에 머지
**실행:** GitHub Actions (자동)

```
[GitHub Actions 워크플로우]
1. 체크아웃
   → actions/checkout@v4

2. 빌드
   → npm ci
   → npm run build
   
3. 테스트
   → npm run test
   
4. Docker 이미지 빌드
   → docker build -t ghcr.io/leocompany/real-estate-cms:abc1234 .
   
5. 이미지 푸시
   → docker push ghcr.io/leocompany/real-estate-cms:abc1234
   
6. Dev 서버 배포
   → SSH 접속: deploy@192.168.1.10
   → /opt/scripts/deploy.sh real-estate-cms abc1234
   
   [deploy.sh 내부]
   - podman pull ghcr.io/leocompany/real-estate-cms:abc1234
   - Quadlet 설정 업데이트
   - systemctl restart real-estate-cms
   - 헬스체크 대기

7. Slack 알림 (MCP)
   → #deployments 채널
   → "✅ Dev 배포 완료: real-estate-cms@abc1234"
```

**결과:** https://dev-realestate.leocompany.com 에서 확인 가능

---

### Step 12: QA 테스트 (사람)

**누가:** PM, 기획자, 또는 QA 담당자
**어디서:** Dev 서버 (dev-realestate.leocompany.com)

**테스트 항목:**
- 매물 등록이 정상 작동하는지
- 이미지 업로드가 되는지
- 검색/필터가 잘 작동하는지
- 모바일에서도 잘 보이는지
- 예외 상황 처리가 되는지

**결과:**
- 버그 발견 시 → GitHub Issue 생성 → Step 6부터 다시
- 문제없으면 → Production 배포 요청

---

### Step 13: Production 배포 (승인 필요)

**누가:** Leo (최종 승인권자)
**무엇을:**
```bash
> /deploy prod real-estate-cms
```

**활성화된 에이전트:** @infra-ops
**참조 Skills:** `leo-infra`, `quadlet-templates`
**사용 MCP:** `GitHub MCP`, `Slack MCP`
**사용 로컬 도구:** `Leo CLI`

**Blue/Green 배포 실행:**

```
[Leo CLI로 배포 스크립트 실행]
/opt/scripts/deploy-bluegreen.sh real-estate-cms abc1234

1. 새 컨테이너 시작 (Blue)
   → Port 3006에서 새 버전 실행
   → 기존 버전은 3005에서 계속 실행 중
   
2. 헬스체크
   → curl http://localhost:3006/api/health
   → 30초간 반복 체크
   → 정상 응답 확인 ✅
   
3. 트래픽 전환
   → Caddy 설정 변경
   → realestate.leocompany.com → localhost:3006
   → caddy reload (무중단)
   
4. 안정화 대기
   → 5분간 모니터링
   → 에러율 정상 ✅
   
5. 구 버전 종료 (Green)
   → Port 3005 컨테이너 종료
   → 리소스 해제

[Slack MCP]
→ #deployments 채널
→ "🚀 Production 배포 완료: real-estate-cms@abc1234"

[롤백 필요 시]
→ Caddy 설정만 3005로 되돌림
→ 30초 내 복구 가능
```

---

### Step 14: 운영 모니터링

**배포 후 자동으로 모니터링 시작:**

```
[Prometheus]
- 메트릭 수집 시작
- real_estate_cms_requests_total
- real_estate_cms_response_time_seconds
- real_estate_cms_error_rate

[Grafana 대시보드]
- 실시간 요청 수 그래프
- 응답 시간 분포 (p50, p95, p99)
- 에러율 추이
- CPU/메모리 사용량

[알림 규칙]
- 에러율 > 5% → Slack #alerts-critical
- 응답시간 p95 > 2초 → Slack #alerts-warning
- 서버 다운 → Slack #alerts-critical + PagerDuty
```

---

## 6.3 전체 타임라인 요약

| 단계 | 담당 | 참조 Skills | 사용 MCP/도구 | 소요 시간 |
|------|------|------------|--------------|----------|
| 요구사항 수집 | @pm-spec + Leo | prd-template | - | 30분~1시간 |
| PRD 승인 | Leo (사람) | - | - | 10분 |
| 인프라 생성 | @infra-ops | leo-infra, podman-guide | GitHub MCP, Leo CLI | 3분 |
| 아키텍처 설계 | @architect | db-patterns, api-conventions | - | 20분 |
| 백엔드 개발 | @backend-dev | core-cms, prisma-guide | GitHub MCP | 2~4시간 |
| 프론트엔드 개발 | @frontend-dev | core-cms, react-patterns | GitHub MCP | 2~4시간 |
| 코드 리뷰 | @qa-gate | code-review-checklist, security-checklist | GitHub MCP | 5분 |
| E2E 테스트 | @e2e-tester | playwright-patterns | GitHub MCP | 10분 |
| PR 리뷰 | Leo/리뷰어 (사람) | - | - | 30분 |
| Dev 배포 | GitHub Actions | - | Slack MCP | 5분 |
| QA 테스트 | PM/기획자 (사람) | - | - | 1~2시간 |
| Prod 배포 | @infra-ops | leo-infra, quadlet-templates | Slack MCP, Leo CLI | 5분 |

**총 예상 시간:** MVP 기준 반나절 ~ 하루 (기존 방식 대비 약 70% 단축)

---

## 6.4 특수 상황 시뮬레이션

### 상황 1: 빌드 실패 시

```
[GitHub Actions에서 빌드 실패]
→ AI 빌드 분석 워크플로우 자동 트리거

[Claude가 에러 로그 분석]
에러: "Cannot find module '@/lib/utils'"
분석: "tsconfig.json의 paths 설정과 실제 파일 경로 불일치"
해결책: "src/lib/utils.ts 파일 생성 또는 import 경로 수정"

[자동 액션]
1. GitHub Issue 자동 생성
   - Title: "🔴 빌드 실패 분석: abc1234"
   - Body: AI 분석 결과 + 해결책
   - Labels: bug, build-failure, ai-analyzed

2. Slack 알림
   → #alerts-ci 채널
   → "빌드 실패: real-estate-cms - 원인 분석 완료"
```

### 상황 2: Production 장애 발생 시

```
[Prometheus 알림 발생]
→ 에러율 10% 초과

[자동 대응]
1. Slack #alerts-critical 알림
   → "🔴 에러율 급증: real-estate-cms (10.2%)"
   → @channel 멘션

2. Grafana 링크 포함
   → 바로 대시보드 확인 가능

[수동 대응 (Leo 또는 담당자)]
1. 대시보드에서 원인 파악
   - 특정 API에서만 에러? → 코드 문제
   - 전체적으로 에러? → 인프라 문제
   
2. 롤백 결정 시
   → leo rollback real-estate-cms
   → Caddy가 이전 버전으로 전환
   → 30초 내 복구

3. 포스트모템 작성
   - 원인, 영향, 대응, 재발 방지책
```

### 상황 3: 신규 개발자 온보딩

```
[Day 1 오전]
1. install-leo-stack.sh 실행
   → Leo CLI 설치
   → Claude Code 설정 동기화
   → SSH 키 등록

2. 첫 프로젝트 클론
   → git clone leocompany/real-estate-cms
   → npm install
   → npm run dev
   → 바로 로컬에서 실행 확인

[Day 1 오후]
3. Claude Code로 코드베이스 파악
   → "이 프로젝트 구조 설명해줘"
   → @orchestrator가 CLAUDE.md 기반으로 설명

4. 첫 번째 작업 할당
   → "매물 상세 페이지에 지도 추가해줘"
   → @orchestrator가 작업 분석
   → @frontend-dev가 가이드

[Day 1 저녁]
5. 첫 PR 생성
   → 자동 리뷰 통과
   → 시니어 리뷰 후 머지

**결과:** 첫날부터 실제 기여 가능
```

---

# Part 7. 보안 고려사항
5. core-cms 템플릿 복제
6. .env.local 자동 생성
7. Caddy 설정 업데이트
8. 모니터링 대시보드 생성

결과: 개발자는 바로 `npm run dev`로 시작 가능

### Step 2: 설계 단계

@architect 에이전트가:
1. PRD 기반 DB 스키마 설계
2. API 엔드포인트 설계
3. 컴포넌트 구조 제안

산출물:
- `docs/database-schema.md`
- `docs/api-specification.md`
- `docs/component-structure.md`

Leo가 설계 검토 후 승인

### Step 3: 기능 개발

개발자가:
```
/feature-dev 매물 등록 기능 개발해줘
```

@orchestrator가 작업 분석 후:
1. @backend-dev에게 API 개발 지시
2. @frontend-dev에게 UI 개발 지시
3. 두 에이전트가 병렬로 작업
4. 결과 통합

실제 실행 흐름:
- @backend-dev: Prisma 스키마 수정 → DB 마이그레이션 → API 라우트 작성
- @frontend-dev: 컴포넌트 작성 → API 연동 → 스타일링
- @qa-gate: 코드 리뷰 → 린트 체크

### Step 4: 테스트

개발 완료 후:
```
테스트 실행해줘
```

@e2e-tester가:
1. 기존 테스트 케이스 실행
2. 새 기능에 대한 테스트 케이스 작성
3. Playwright로 E2E 테스트 실행
4. 결과 리포트 생성

테스트 통과 시:
- GitHub PR 자동 생성 (MCP 연동)
- 리뷰어 자동 지정

### Step 5: 배포

Leo의 최종 승인 후:
```
/deploy prod real-estate-cms
```

@infra-ops가:
1. GitHub Actions 트리거
2. 빌드 및 테스트
3. Blue/Green 배포 실행:
   - 새 컨테이너 띄우기 (예: 포트 3006)
   - Health Check 대기
   - Caddy 프록시 전환 (3005 → 3006)
   - 구 컨테이너 종료

배포 완료 후:
- Slack 알림: "🚀 배포 완료: 부동산 관리 시스템"
- 모니터링 대시보드에서 상태 확인

---

## 6.2 일상적인 개발 사이클

### 아침: 컨텍스트 로드

개발자가 출근해서 터미널을 열고:
```bash
cd ~/projects/real-estate-cms
claude
```

Claude Code가 CLAUDE.md를 읽고 프로젝트 맥락을 파악.

"어제 매물 등록 기능 작업 중이었는데, 이미지 업로드 부분 마저 해야 해"

@orchestrator: "이미지 업로드 기능을 구현하겠습니다. S3 연동은 MinIO를 사용하고, 이미지 리사이징은 Sharp 라이브러리로 처리할까요?"

### 오전: 기능 개발

개발자와 Claude가 핑-퐁 방식으로 작업:
1. 개발자: 요구사항 설명 / 피드백
2. Claude: 코드 생성 / 수정
3. 개발자: 테스트 / 리뷰
4. Claude: 개선 / 리팩토링

이 과정에서 Claude는:
- 파일 직접 생성/수정
- 터미널 명령어 실행
- Git 커밋 생성

개발자는:
- 방향성 제시
- 품질 검증
- 최종 결정

### 오후: 통합 및 테스트

기능 완성 후:
```
PR 만들어줘
```

Claude가:
1. 변경사항 요약
2. Git 브랜치 생성
3. 커밋 푸시
4. PR 생성 (MCP로 GitHub API 호출)

자동화된 CI가:
- 린트 체크
- 유닛 테스트
- E2E 테스트

### 저녁: 리뷰 및 머지

다른 팀원(또는 Leo)이 PR 리뷰:
- 코드 품질 확인
- 비즈니스 로직 검증
- 성능 고려사항

승인 후 머지 → 자동 배포 (develop 브랜치는 dev 서버로)

---

## 6.3 비상 상황 대응

### 시나리오: 프로덕션 에러 발생

**1분: 알림 수신**
Slack #alerts-critical: "🔴 에러율 급증: real-estate-cms"

**2분: 상황 파악**
Grafana 대시보드 확인:
- 에러율 그래프 급상승
- 어떤 엔드포인트에서 에러 발생 중인지
- 최근 배포 이력

**5분: 원인 분석**
Loki에서 로그 확인:
- 에러 메시지 검색
- 스택 트레이스 분석
- 최근 변경사항과의 연관성

**10분: 결정**
- 롤백 필요 시: `leo rollback real-estate-cms`
- 핫픽스 가능 시: 수정 후 긴급 배포

**15분: 조치 완료**
- 서비스 정상화 확인
- 포스트모템 문서 작성

---

# Part 7. 보안 고려사항

## 7.1 시크릿 관리

### 현재의 문제

.env 파일에 DB 패스워드, API 키 같은 민감 정보가 들어간다. 이 파일을 어떻게 관리할 것인가?

**나쁜 방법들:**
- .env 파일을 Git에 커밋 (절대 금지)
- 슬랙으로 패스워드 공유 (위험)
- 구글 시트에 정리 (노출 위험)

### 선택한 방법: git-crypt + 환경변수 템플릿

**git-crypt**
- Git 리포지토리의 특정 파일을 자동 암호화
- `.gitattributes`에 암호화할 파일 패턴 지정
- 권한 있는 사람만 복호화 가능

**환경변수 템플릿**
- `.env.template`: 키 이름만 있고 값은 비어있음
- `.env.local`: 실제 값이 들어있음 (git-crypt로 암호화)

**프로세스:**
1. 새 개발자 합류 → git-crypt GPG 키 등록
2. `git-crypt unlock` → .env.local 복호화
3. 개발 진행

### 향후 개선: Vault 도입

HashiCorp Vault를 도입하면:
- 시크릿의 버전 관리
- 접근 로그 감사
- 자동 시크릿 로테이션
- 동적 데이터베이스 크리덴셜

현재 규모에서는 오버엔지니어링이지만, 팀이 커지면 고려.

---

## 7.2 네트워크 보안

### 외부 노출 최소화

**Caddy (리버스 프록시)만 외부 노출**
- 443 포트 (HTTPS)만 열림
- 자동 SSL 인증서 (Let's Encrypt)

**나머지 서버는 내부망**
- DB 서버: 외부에서 직접 접근 불가
- Redis 서버: 외부에서 직접 접근 불가
- 개발자가 접근할 때는 SSH 터널링

### SSH 보안 강화

**패스워드 인증 비활성화**
- SSH 키 인증만 허용
- 브루트포스 공격 차단

**포트 변경**
- 기본 22번 대신 다른 포트 사용
- 자동화된 스캔 회피

**fail2ban**
- 로그인 실패 시 IP 차단
- 반복 시도 방지

### 방화벽 규칙

**APP Server (192.168.1.10)**
- 80, 443: 전체 허용 (웹)
- SSH 포트: 사무실 IP만 허용

**DB Server (192.168.1.11)**
- 5432: 내부 네트워크만 허용
- SSH 포트: 사무실 IP만 허용

**Redis Server (192.168.1.14)**
- 6379: 내부 네트워크만 허용

---

## 7.3 애플리케이션 보안

### 인증/인가

**NextAuth.js 사용**
- 세션 기반 인증
- JWT 옵션 가능
- 소셜 로그인 지원

**역할 기반 접근 제어 (RBAC)**
- Admin: 모든 기능 접근
- Editor: 컨텐츠 수정 가능
- Viewer: 읽기만 가능

### 일반적인 취약점 방지

**SQL Injection**
- Prisma ORM 사용 → 자동 파라미터화
- Raw 쿼리 사용 시 주의

**XSS**
- React의 기본 이스케이핑
- dangerouslySetInnerHTML 사용 금지

**CSRF**
- NextAuth의 CSRF 토큰
- SameSite 쿠키 속성

---

# Part 8. 기대 효과 및 로드맵

## 8.1 이 시스템이 가져올 변화

### 정량적 기대 효과

**프로젝트 초기 설정 시간**
- Before: 2-3일 (환경 세팅, DB 설정, 배포 파이프라인...)
- After: 30분 (자동화된 템플릿과 스크립트)
- 개선: 약 90% 감소

**컨텍스트 스위칭 비용**
- Before: 프로젝트 전환마다 30분 (설정 파악, 환경 변수 확인...)
- After: 5분 (표준화된 구조, CLAUDE.md)
- 개선: 약 80% 감소

**온보딩 시간**
- Before: 신규 개발자 2주 (프로젝트별 학습)
- After: 3일 (공통 Core CMS 학습 → 모든 프로젝트 이해)
- 개선: 약 75% 감소

**배포 시간**
- Before: 수동 배포 30분 + 불안함
- After: 자동 배포 5분 + Blue/Green으로 안전
- 개선: 약 80% 감소

### 정성적 기대 효과

**인지 부하 감소**
"이 프로젝트는 어떻게 되어있지?"라는 고민이 사라진다. 모든 프로젝트가 같은 구조니까.

**불안감 해소**
"이거 배포해도 될까?"라는 두려움이 줄어든다. 자동화된 테스트와 롤백이 있으니까.

**협업 효율성**
"이거 어떻게 하면 돼?"라는 질문이 줄어든다. Skills와 문서가 있으니까.

**AI 활용 민주화**
"Claude 잘 쓰는 사람만 생산성 높다"가 아니라, 팀 전체가 AI의 혜택을 받는다.

---

## 8.2 구현 로드맵

### Phase 1: Foundation (1-2주)

**목표**: 기반 인프라 구축

**작업 내용**:
1. infra-framework 리포지토리 생성
2. projects/*.yml 스키마 확정
3. leo-manager 핵심 기능 구현
   - register 명령어
   - list 명령어
4. Core CMS 템플릿 v1.0 완성
5. CLAUDE.md 템플릿 작성

**산출물**:
- 동작하는 leo-manager CLI
- Core CMS 템플릿 리포지토리
- 프로젝트 매니페스트 샘플

### Phase 2: Automation (2-3주)

**목표**: 자동화 파이프라인 구축

**작업 내용**:
1. Caddy 자동 설정 업데이트
2. GitHub Actions CI/CD 템플릿
3. Blue/Green 배포 스크립트
4. 환경변수 자동 주입 시스템

**산출물**:
- 원클릭 프로젝트 생성
- 자동 배포 파이프라인

### Phase 3: Monitoring (1-2주)

**목표**: 모니터링 스택 구축

**작업 내용**:
1. Prometheus 설치 및 설정
2. Loki 설치 및 설정
3. Grafana 대시보드 템플릿
4. 알림 규칙 설정

**산출물**:
- 실시간 모니터링 대시보드
- 자동 알림 시스템

### Phase 4: AI Integration (2-3주)

**목표**: Claude Code 에이전트 시스템 구축

**작업 내용**:
1. 서브에이전트 설정 파일 작성
2. Skills 문서 작성
3. MCP 연동 (GitHub, Slack)
4. 커스텀 명령어 정의

**산출물**:
- 동작하는 에이전트 시스템
- 팀 공유 가능한 설정

### Phase 5: Documentation & Rollout (1-2주)

**목표**: 팀 배포 및 교육

**작업 내용**:
1. 팀원용 온보딩 가이드
2. 설치 스크립트 (install-leo-stack.sh)
3. 트러블슈팅 가이드
4. 팀 교육 세션

**산출물**:
- 완성된 시스템 문서
- 운영 중인 시스템

---

## 8.3 성공 지표 (KPIs)

### 측정 가능한 지표

**채택률**
- 목표: 모든 신규 프로젝트가 Core CMS 사용
- 측정: 리포지토리 템플릿 사용 비율

**배포 빈도**
- 목표: 주 10회 이상 배포
- 측정: GitHub Actions 실행 횟수

**배포 실패율**
- 목표: 5% 미만
- 측정: 배포 후 롤백 횟수

**평균 복구 시간 (MTTR)**
- 목표: 15분 이내
- 측정: 알림 발생 → 정상화까지 시간

**개발자 만족도**
- 목표: 4점/5점 이상
- 측정: 분기별 서베이

---

# 결론: 왜 지금 이걸 해야 하는가

## 이 시스템의 본질

이 문서에서 설명한 시스템은 단순한 도구 모음이 아니다. 이건 **"개발팀이 어떻게 일해야 하는가"**에 대한 철학이다.

핵심 믿음:
1. **표준화가 자유를 준다**: 규칙 안에서 더 창의적일 수 있다
2. **자동화가 사람을 자유롭게 한다**: 반복 작업에서 벗어나 가치 있는 일에 집중
3. **AI는 도구이지 마법이 아니다**: 제대로 된 구조 안에서 AI는 10배의 가치를 낸다

## 타이밍

왜 지금인가?

1. **Claude Code가 충분히 성숙했다**: 1년 전만 해도 이런 시스템은 불가능했다
2. **팀이 커지기 전이 적기다**: 10명이 되면 바꾸기 어렵다. 6명일 때 기반을 잡아야 한다
3. **기술 부채는 복리로 쌓인다**: 지금 1시간 투자해서 막을 일을 나중에는 1주일 걸려도 못 막는다

## 최종 비전

6개월 후, 이런 장면을 상상한다:

> 신규 개발자가 첫 출근한다.
> 
> 오전: install-leo-stack.sh 실행, 환경 세팅 완료
> 
> 점심 전: Core CMS 구조 파악, 첫 번째 프로젝트 열어보기
> 
> 오후: claude 실행, "이 프로젝트에서 내가 할 일이 뭐지?" 질문
> 
> @orchestrator가 백로그를 보여주고, 첫 번째 작업을 안내한다.
> 
> 퇴근 전: 첫 번째 PR이 머지된다.

이게 가능한 팀. 이게 우리가 만들어가는 Leo Company의 개발 문화다.

---

**문서 끝**

*이 문서는 지속적으로 업데이트됩니다. 최신 버전은 Git 리포지토리에서 확인하세요.*